"""
common_ledger.py
1장 문제01에서 확정한 표준 순매출 원장 빌더.
2장~10장의 모든 스크립트가 이 모듈의 build_ledger()를 재사용한다.
"""

import pandas as pd


def build_ledger(
    orders_path="data/orders.csv",
    items_path="data/order_items.csv",
    verbose=False,
):
    """
    정제 순서: 중복 제거 -> 날짜 파싱(coerce) -> 기간 필터(2024 상반기)
             -> order_id 기준 inner join -> unit_price 결측 제외 -> line_amount 파생
    반환: 라인 단위 데이터프레임 (is_net 열: canceled/returned 제외 여부)
    """
    orders = pd.read_csv(orders_path)
    items = pd.read_csv(items_path)

    orders = orders.drop_duplicates()
    items = items.drop_duplicates()

    orders["order_datetime"] = pd.to_datetime(orders["order_datetime"], errors="coerce")
    period_mask = (orders["order_datetime"] >= "2024-01-01") & (
        orders["order_datetime"] < "2024-07-01"
    )
    orders_in_period = orders[period_mask].copy()

    ledger = orders_in_period.merge(items, on="order_id", how="inner")
    ledger = ledger.dropna(subset=["unit_price"]).copy()
    ledger["line_amount"] = (
        ledger["quantity"] * ledger["unit_price"] * (1 - ledger["discount"])
    )
    ledger["is_net"] = ~ledger["status"].isin(["canceled", "returned"])

    if verbose:
        net_rev = ledger.loc[ledger["is_net"], "line_amount"].sum()
        net_orders = ledger.loc[ledger["is_net"], "order_id"].nunique()
        print(f"[공통 원장] 라인 {len(ledger):,}건 / 상반기 순매출 {net_rev:,.0f}원 / 유효 주문 {net_orders:,}건")

    return ledger


def net_ledger(orders_path="data/orders.csv", items_path="data/order_items.csv"):
    """취소·반품이 제외된 순매출 라인만 반환 (자주 쓰는 축약형)"""
    ledger = build_ledger(orders_path, items_path)
    return ledger[ledger["is_net"]].copy()


def clean_category(series):
    """카테고리 앞뒤 공백 오염 정제 공통 함수 (5장~에서 재사용)"""
    return series.astype(str).str.strip()


def clean_price(series):
    """products.price 문자열 오염 정제: 콤마·원 제거 후 숫자화, 형식오염은 NaN"""
    cleaned = (
        series.astype(str)
        .str.replace(",", "", regex=False)
        .str.replace("원", "", regex=False)
        .str.strip()
    )
    return pd.to_numeric(cleaned, errors="coerce")
