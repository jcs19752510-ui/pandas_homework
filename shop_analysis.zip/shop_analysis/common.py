# -*- coding: utf-8 -*-
"""
common.py
=========
전 장에서 공통으로 쓰는 '표준 순매출 원장' 구축 함수를 모아둔 모듈입니다.

표준 순매출 원장이란? (문제 01에서 도출한 매출 기준)
  - orders + order_items 를 order_id 로 결합한 "주문 라인 단위" 표
  - 처리 순서: 완전 중복 행 제거 → order_datetime 파싱(errors="coerce") →
    2024년 상반기(1/1~6/30) 기간 필터 → 상태 필터
  - 총매출: 모든 상태 포함 (취소/반품 포함)
  - 순매출: canceled·returned 를 제외한 값
  - 라인 금액(line_amount) = quantity * unit_price * (1 - discount)

이 파일의 함수들을 각 장의 스크립트에서 import 해서 재사용합니다.
"""

import pandas as pd
import numpy as np
import os

DATA_DIR = os.environ.get("SHOP_DATA_DIR", "data")


def _path(name: str) -> str:
    return os.path.join(DATA_DIR, name)


def load_orders() -> pd.DataFrame:
    """orders.csv 를 읽습니다. (원본 그대로, 정제는 build_net_sales_ledger 에서 수행)"""
    return pd.read_csv(_path("orders.csv"))


def load_order_items() -> pd.DataFrame:
    """order_items.csv 를 읽습니다."""
    return pd.read_csv(_path("order_items.csv"))


def load_products() -> pd.DataFrame:
    """products.csv 를 읽고 category 앞뒤 공백, price 형식 오염을 함께 정제해 반환합니다."""
    products = pd.read_csv(_path("products.csv"))
    # category 앞뒤 공백 오염 정제 (예: '가구 ' -> '가구')
    products["category"] = products["category"].astype(str).str.strip()
    # price는 object 타입(콤마·'원' 문자 오염) -> 숫자로 변환, 실패하면 NaN
    products["price_clean"] = (
        products["price"]
        .astype(str)
        .str.replace(",", "", regex=False)
        .str.replace("원", "", regex=False)
        .str.strip()
    )
    products["price_clean"] = pd.to_numeric(products["price_clean"], errors="coerce")
    return products


def load_customers() -> pd.DataFrame:
    """customers.csv 를 읽고 birth_date 를 datetime 으로 변환합니다."""
    customers = pd.read_csv(_path("customers.csv"))
    customers["birth_date"] = pd.to_datetime(customers["birth_date"], errors="coerce")
    customers["signup_date"] = pd.to_datetime(customers["signup_date"], errors="coerce")
    return customers


def load_web_logs(usecols=None, dtype=None) -> pd.DataFrame:
    """web_logs.csv 를 읽습니다. 100만 행이므로 usecols/dtype 지정을 권장합니다."""
    web_logs = pd.read_csv(_path("web_logs.csv"), usecols=usecols, dtype=dtype)
    if "event_time" in web_logs.columns:
        web_logs["event_time"] = pd.to_datetime(web_logs["event_time"], errors="coerce")
    return web_logs


PERIOD_START = pd.Timestamp("2024-01-01")
PERIOD_END = pd.Timestamp("2024-06-30 23:59:59")


def build_net_sales_ledger(orders: pd.DataFrame = None, order_items: pd.DataFrame = None,
                            verbose: bool = True):
    """
    표준 순매출 원장을 만듭니다. (문제 01 핵심 로직)

    반환값: dict
      - "gross_ledger": 정제 후 전체 상태 포함 라인 단위 DataFrame (총매출용)
      - "net_ledger":    canceled/returned 제외한 라인 단위 DataFrame (순매출용)
      - "audit":         정제 단계별 손실 건수를 담은 대사표(DataFrame)
    """
    if orders is None:
        orders = load_orders()
    if order_items is None:
        order_items = load_order_items()

    audit_rows = []
    audit_rows.append({"단계": "0. 원본 order_items 행수", "건수": len(order_items)})

    # 1) 완전 중복 행 제거
    items = order_items.drop_duplicates()
    audit_rows.append({"단계": "1. order_items 중복 제거 후", "건수": len(items),
                        "제거건수": len(order_items) - len(items)})

    # 2) orders 와 결합 (주문 라인 단위)
    ledger = items.merge(orders, on="order_id", how="left", validate="many_to_one")
    audit_rows.append({"단계": "2. orders 결합 후(라인 단위)", "건수": len(ledger)})

    # 3) order_datetime 타입 오염 정제: errors="coerce" -> 파싱 실패는 NaT
    before_na = ledger["order_datetime"].isna().sum()
    ledger["order_datetime"] = pd.to_datetime(ledger["order_datetime"], errors="coerce")
    after_na = ledger["order_datetime"].isna().sum()
    lost_by_parse = after_na - before_na
    ledger_dated = ledger.dropna(subset=["order_datetime"])
    audit_rows.append({"단계": "3. 날짜 파싱 실패 제거", "건수": len(ledger_dated),
                        "제거건수": lost_by_parse})

    # 4) 2024년 상반기 기간 밖 제거
    in_period = ledger_dated["order_datetime"].between(PERIOD_START, PERIOD_END)
    ledger_period = ledger_dated[in_period]
    audit_rows.append({"단계": "4. 상반기 기간 필터 후", "건수": len(ledger_period),
                        "제거건수": len(ledger_dated) - len(ledger_period)})

    # 5) 라인 금액 파생 (할인 반영)
    ledger_period = ledger_period.copy()
    ledger_period["line_amount"] = (
        ledger_period["quantity"] * ledger_period["unit_price"] * (1 - ledger_period["discount"])
    )

    gross_ledger = ledger_period  # 총매출: 모든 상태 포함

    # 6) 순매출: canceled/returned 제외
    net_ledger = ledger_period[~ledger_period["status"].isin(["canceled", "returned"])]
    audit_rows.append({"단계": "5. 순매출(취소·반품 제외) 후", "건수": len(net_ledger),
                        "제거건수": len(ledger_period) - len(net_ledger)})

    audit = pd.DataFrame(audit_rows)

    if verbose:
        print("=" * 60)
        print("[표준 순매출 원장] 정제 단계별 대사표")
        print(audit.to_string(index=False))
        print(f"총매출(gross) 라인 수: {len(gross_ledger):,} / "
              f"순매출(net) 라인 수: {len(net_ledger):,}")
        print(f"순매출 합계: {net_ledger['line_amount'].sum():,.0f} 원")
        print("=" * 60)

    return {"gross_ledger": gross_ledger, "net_ledger": net_ledger, "audit": audit}


def valid_orders_only(orders: pd.DataFrame = None) -> pd.DataFrame:
    """orders 헤더만 정제(중복 없음, 날짜 파싱, 기간 필터, 취소/반품 제외)해서 반환.
    (금액이 필요 없고 '주문 건수'만 셀 때 사용 - 문제05, 19 등)
    """
    if orders is None:
        orders = load_orders()
    orders = orders.copy()
    orders["order_datetime"] = pd.to_datetime(orders["order_datetime"], errors="coerce")
    orders = orders.dropna(subset=["order_datetime"])
    orders = orders[orders["order_datetime"].between(PERIOD_START, PERIOD_END)]
    orders = orders[~orders["status"].isin(["canceled", "returned"])]
    return orders
