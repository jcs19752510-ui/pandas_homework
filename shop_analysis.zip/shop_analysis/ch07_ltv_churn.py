# -*- coding: utf-8 -*-
"""
7장. 고객 생애가치와 이탈 관리
  문제 17: 6개월 실현 LTV와 가치 집중도
  문제 18: 코호트별 LTV 곡선과 획득비 상한
  문제 19: 이탈 기준선 탐색과 민감도
  문제 20: 이탈 위험 스코어카드
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, load_products, load_customers, valid_orders_only, load_web_logs

OBS_END = pd.Timestamp("2024-06-30")


def _net_with_margin():
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    products = load_products().drop_duplicates(subset=["product_id"])
    net = net.merge(products[["product_id", "cost"]], on="product_id", how="left")
    net["margin"] = net["quantity"] * (net["unit_price"] * (1 - net["discount"]) - net["cost"])
    return net


def problem_17():
    print("\n########## 문제 17: 6개월 실현 LTV와 가치 집중도 ##########")
    net = _net_with_margin()
    customers = load_customers()

    ltv = net.groupby("customer_id").agg(매출LTV=("line_amount", "sum"), 마진LTV=("margin", "sum"))
    print(f"\n주문에 등장하는 고유 고객수: {net['customer_id'].nunique():,} / "
          f"고객 마스터 고유 고객수: {customers['customer_id'].nunique():,}")

    for col in ["매출LTV", "마진LTV"]:
        s = ltv[col]
        stats = pd.Series({
            "평균": s.mean(), "중앙값": s.median(),
            "P90": s.quantile(0.90), "P99": s.quantile(0.99),
        })
        top10_share = s.sort_values(ascending=False).head(int(len(s) * 0.10)).sum() / s.sum()
        print(f"\n[{col} 분포]")
        print(stats.round(0).to_string())
        print(f"상위 10% 고객의 {col} 점유율: {top10_share:.1%}")

    print(
        "\n결론: 평균은 중앙값보다 훨씬 크고, 상위 10% 고객이 전체 가치의 상당 부분을 차지합니다. "
        "따라서 '평균 LTV 5만원이니 5만원까지 획득비를 써도 된다'는 논리는 소수 대형 고객이 "
        "끌어올린 평균을 전체 신규 고객에게 일반화하는 오류입니다. 획득비 상한은 중앙값 또는 "
        "고객 세그먼트별 분포를 근거로 삼아야 합니다."
    )
    return ltv


def problem_18():
    print("\n########## 문제 18: 코호트별 LTV 곡선과 획득비 상한 ##########")
    net = _net_with_margin()
    order_level = net.groupby(["customer_id", "order_id"]).agg(
        order_dt=("order_datetime", "max"),
        amount=("line_amount", "sum"),
        margin=("margin", "sum"),
    ).reset_index()

    first_dt = order_level.groupby("customer_id")["order_dt"].min().rename("first_dt")
    order_level = order_level.merge(first_dt, on="customer_id")
    order_level["cohort"] = order_level["first_dt"].dt.to_period("M")
    order_level["period_n"] = (
        order_level["order_dt"].dt.to_period("M") - order_level["cohort"]
    ).apply(lambda x: x.n)

    cohort_size = order_level.groupby("cohort")["customer_id"].nunique()
    monthly_sum = order_level.groupby(["cohort", "period_n"])["margin"].sum().unstack(fill_value=0)
    per_customer = monthly_sum.div(cohort_size, axis=0)
    cumulative = per_customer.cumsum(axis=1)

    print("\n[코호트별 경과월 1인당 누적 마진(LTV) 곡선]")
    print(cumulative.round(0).to_string())

    shape = "초기 집중형" if cumulative.iloc[:, 0].mean() / cumulative.iloc[:, -1].mean() > 0.4 else "지속 누적형"
    print(f"\n곡선 형태 판정: {shape}")

    # 90일 시점 1인당 마진: 첫구매 후 실제 날짜 90일 창, 관측 종료(6/30) 안에 들어오는 코호트만
    order_level["days_since_first"] = (order_level["order_dt"] - order_level["first_dt"]).dt.days
    window90 = order_level[order_level["days_since_first"].between(0, 90)]
    eligible_customers = order_level.groupby("customer_id")["first_dt"].min()
    eligible_customers = eligible_customers[eligible_customers + pd.Timedelta(days=90) <= OBS_END]
    window90_eligible = window90[window90["customer_id"].isin(eligible_customers.index)]

    margin_90d_per_customer = window90_eligible.groupby("customer_id")["margin"].sum()
    avg_margin_90d = margin_90d_per_customer.reindex(eligible_customers.index, fill_value=0).mean()
    print(f"\n90일 관측 완료 코호트 고객수: {len(eligible_customers):,}")
    print(f"첫 구매 후 90일 시점 1인당 평균 마진: {avg_margin_90d:,.0f} 원")

    print(
        f"\n[획득비 상한 제안] 가정1) '마진 회수 기간 90일' 정책 채택, 가정2) 90일 평균 마진 "
        f"{avg_margin_90d:,.0f}원을 그대로 획득비 상한으로 사용(안전마진 미고려 상한), "
        f"가정3) 6개월 관측 데이터 특성상 후속 코호트의 장기 곡선은 미관측 — 상한을 보수적으로 "
        f"{avg_margin_90d * 0.8:,.0f}원(80%) 수준까지 낮춰 운용할 것을 권고합니다."
    )
    return cumulative


def problem_19():
    print("\n########## 문제 19: 이탈 기준선 탐색과 민감도 ##########")
    orders = valid_orders_only().sort_values(["customer_id", "order_datetime"])

    orders["prev_dt"] = orders.groupby("customer_id")["order_datetime"].shift(1)
    orders["gap_days"] = (orders["order_datetime"] - orders["prev_dt"]).dt.days
    gaps = orders["gap_days"].dropna()

    single_purchase = orders.groupby("customer_id").size()
    n_single = (single_purchase == 1).sum()
    print(f"주문 1회 고객(간격 없음, 분포에서 제외): {n_single:,}명")

    p75, p90 = gaps.quantile(0.75), gaps.quantile(0.90)
    print(f"\n재구매 간격 분포: P75={p75:.1f}일, P90={p90:.1f}일")

    last_purchase = orders.groupby("customer_id")["order_datetime"].max()
    recency = (OBS_END.normalize() - last_purchase.dt.normalize()).dt.days

    candidates = [60, 90, 120, int(p75), int(p90)]
    sensitivity = pd.Series({th: (recency > th).mean() for th in sorted(set(candidates))})
    print("\n[기준선 후보별 이탈률 민감도 표]")
    print((sensitivity * 100).round(1).to_string())

    recommended = int(p75)
    print(f"\n권고 기준선: {recommended}일 (재구매 간격 P75 기준). 사내 통념 90일보다 짧게 잡아, "
          "상위 75% 고객의 정상 재구매 주기를 벗어난 시점을 조기 경보로 사용합니다.")
    print(
        "※ 관측 종료일(6/30) 근처에 마지막 구매가 있는 고객은 recency가 작아 '이탈 아님'으로 "
        "보이지만, 실제로는 그 이후 이탈했을 수도, 안 했을 수도 있는 '검열(censoring)' 상태로, "
        "현재로선 이탈 여부가 확정되지 않은 고객임을 유의해야 합니다."
    )
    return sensitivity


def problem_20():
    print("\n########## 문제 20: 이탈 위험 스코어카드 ##########")
    orders = valid_orders_only()
    net = build_net_sales_ledger(verbose=False)["net_ledger"]

    last_purchase = orders.groupby("customer_id")["order_datetime"].max()
    recency = (OBS_END.normalize() - last_purchase.dt.normalize()).dt.days
    frequency = orders.groupby("customer_id")["order_id"].nunique()
    value = net.groupby("customer_id")["line_amount"].sum()

    logs = load_web_logs(usecols=["customer_id", "event_time"])
    june_visitors = set(
        logs.loc[logs["event_time"].dt.to_period("M") == pd.Period("2024-06", "M"), "customer_id"].dropna()
    )

    score = pd.DataFrame({"recency": recency, "frequency": frequency, "value": value}).dropna()

    # recency 점수: 문제19의 이탈선(60일)보다 앞선 값으로 조기경보 (0=안전, 2=위험)
    score["r_score"] = pd.cut(score["recency"], bins=[-1, 20, 40, np.inf], labels=[0, 1, 2]).astype(int)
    # frequency 점수: 분위수 기반 (적을수록 위험)
    f_q1, f_q2 = frequency.quantile([0.33, 0.66])
    score["f_score"] = pd.cut(score["frequency"], bins=[-1, f_q1, f_q2, np.inf], labels=[2, 1, 0]).astype(int)
    # 로그 방문 점수: 6월 미방문=2점(위험), 방문=0점
    score["visited_june"] = score.index.isin(june_visitors)
    score["v_score"] = np.where(score["visited_june"], 0, 2)

    score["risk_score"] = score["r_score"] + score["f_score"] + score["v_score"]

    print("\n[스코어 규칙표]")
    print("  recency: <=20일 0점 / 21~40일 1점 / 40일초과 2점")
    print("  frequency: 상위33% 0점 / 중간33% 1점 / 하위33% 2점")
    print("  6월 로그 방문: 방문 0점 / 미방문 2점")
    print("  위험점수 = 세 점수 합 (0~6, 클수록 위험)")

    value_median = score["value"].median()
    score["가치군"] = np.where(score["value"] >= value_median, "고가치", "저가치")
    score["위험군"] = np.where(score["risk_score"] >= 4, "고위험", "저위험")

    cross = pd.crosstab(score["위험군"], score["가치군"])
    print("\n[위험 x 가치 분포]")
    print(cross.to_string())

    priority = score[(score["위험군"] == "고위험") & (score["가치군"] == "고가치")]
    print(f"\n우선 관리군(고위험x고가치) 고객수: {len(priority):,}")

    # 연 환산 가정 명시: 상반기(6개월) 실현가치 x 2 = 연 환산
    annualized_loss = priority["value"].sum() * 2
    print(f"우선 관리군 상반기 순매출 합: {priority['value'].sum():,.0f}원")
    print(f"이들이 전원 이탈할 경우 예상 연 매출 손실(6개월치 x2 연환산 가정): "
          f"{annualized_loss:,.0f}원")
    return score


if __name__ == "__main__":
    problem_17()
    problem_18()
    problem_19()
    problem_20()
