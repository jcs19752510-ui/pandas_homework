# -*- coding: utf-8 -*-
"""
2장. 고객 세분화 — RFM과 타깃 목록
  문제 03: RFM 스코어 산출과 세그먼트 정의
  문제 04: 멤버십 등급제 설계 시뮬레이션
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, load_customers

RFM_ANCHOR_DATE = pd.Timestamp("2024-07-01")


def _customer_rfm(net_ledger: pd.DataFrame) -> pd.DataFrame:
    """주문 라인 원장 -> 고객 단위 R/F/M 테이블"""
    order_level = (
        net_ledger.groupby(["customer_id", "order_id"])
        .agg(order_amount=("line_amount", "sum"), order_dt=("order_datetime", "max"))
        .reset_index()
    )
    rfm = order_level.groupby("customer_id").agg(
        last_purchase=("order_dt", "max"),
        F=("order_id", "nunique"),
        M=("order_amount", "sum"),
    )
    rfm["R"] = (RFM_ANCHOR_DATE - rfm["last_purchase"]).dt.days
    return rfm.reset_index()


def problem_03():
    print("\n########## 문제 03: RFM 스코어 산출과 세그먼트 정의 ##########")
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    customers = load_customers()

    rfm = _customer_rfm(net)
    # 구매 이력이 없는 고객: customers 마스터에는 있지만 net 원장(구매)에는 없는 고객
    # -> RFM 분석 대상에서 제외한다는 규칙을 명시 (분석은 '구매 경험이 있는 고객'만 대상)
    n_no_purchase = customers.loc[
        ~customers["customer_id"].isin(rfm["customer_id"]), "customer_id"
    ].nunique()
    n_order_only = rfm.loc[
        ~rfm["customer_id"].isin(customers["customer_id"]), "customer_id"
    ].nunique()
    print(f"구매 이력이 없는 고객 수(RFM 분석 대상 제외): {n_no_purchase:,}명")
    print(f"참고: 고객 마스터에 없는데 주문에만 등장하는 customer_id: {n_order_only:,}명 "
          "(마스터-주문 정합성 이슈)")
    print("※ orders 에는 customers 마스터(5,000명)보다 많은 customer_id가 등장하는 정합성 "
          "이슈가 있어, RFM은 '실제 구매가 있는 고객' 기준으로만 산출합니다.")

    # R은 작을수록 좋은 점수 -> 라벨 방향 반대로. F는 동점이 많을 수 있어 rank(method="first") 사용
    rfm["R_score"] = pd.qcut(rfm["R"], 5, labels=[5, 4, 3, 2, 1]).astype(int)
    rfm["F_score"] = pd.qcut(rfm["F"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
    rfm["M_score"] = pd.qcut(rfm["M"], 5, labels=[1, 2, 3, 4, 5]).astype(int)
    rfm["RFM_total"] = rfm["R_score"] + rfm["F_score"] + rfm["M_score"]

    def segment(row):
        r, f, m = row["R_score"], row["F_score"], row["M_score"]
        if r >= 4 and f >= 4 and m >= 4:
            return "챔피언"
        if f >= 4 and m >= 3:
            return "충성"
        if r >= 4 and f <= 2:
            return "잠재_충성(신규유망)"
        if r <= 2 and f >= 3:
            return "이탈_위험"
        if r <= 2 and f <= 2:
            return "휴면"
        return "일반"

    rfm["segment"] = rfm.apply(segment, axis=1)

    seg_summary = rfm.groupby("segment").agg(
        인원=("customer_id", "nunique"), 매출합=("M", "sum")
    )
    seg_summary["매출비중"] = seg_summary["매출합"] / seg_summary["매출합"].sum()
    print("\n[세그먼트 정의 규칙표]")
    print("  챔피언: R>=4 & F>=4 & M>=4")
    print("  충성: F>=4 & M>=3")
    print("  잠재_충성(신규유망): R>=4 & F<=2")
    print("  이탈_위험: R<=2 & F>=3")
    print("  휴면: R<=2 & F<=2")
    print("  일반: 나머지")
    print("\n[세그먼트별 인원·매출 비중]")
    print(seg_summary.round(3).to_string())
    return rfm


def problem_04(rfm: pd.DataFrame = None):
    print("\n########## 문제 04: 멤버십 등급제 설계 시뮬레이션 ##########")
    if rfm is None:
        rfm = problem_03()

    m = rfm["M"]

    # 안 A: qcut - 상위 5% / 다음 15% / 나머지 80%
    plan_a = pd.qcut(m.rank(method="first"), [0, 0.80, 0.95, 1.0],
                      labels=["실버", "골드", "VIP"])
    # 안 B: cut - 고정 금액 컷 (100만원 이상 VIP, 30만원 이상 골드, 나머지 실버)
    plan_b = pd.cut(m, bins=[-np.inf, 300_000, 1_000_000, np.inf],
                     labels=["실버", "골드", "VIP"])

    def summarize(plan, name):
        tbl = pd.DataFrame({"등급": plan, "M": m})
        summary = tbl.groupby("등급", observed=True).agg(
            인원=("M", "size"), 매출합=("M", "sum")
        )
        # 등급 중 인원이 0명인 경우도 표에 0으로 남도록 전체 라벨로 재색인
        summary = summary.reindex(["실버", "골드", "VIP"]).fillna(0)
        summary["매출_커버리지"] = summary["매출합"] / m.sum()
        summary.insert(0, "설계안", name)
        return summary

    summary_a = summarize(plan_a, "안A(비율 qcut)")
    summary_b = summarize(plan_b, "안B(금액 cut)")
    compare = pd.concat([summary_a, summary_b])
    print("\n[두 설계안 비교표: 인원·매출 커버리지]")
    print(compare.round(3).to_string())

    # 경계 근처 고객 수 (안B 기준, 100만원/30만원 경계 ±5% 구간)
    near_1m = m.between(1_000_000 * 0.95, 1_000_000 * 1.05).sum()
    near_300k = m.between(300_000 * 0.95, 300_000 * 1.05).sum()
    print(f"\n경계 근처(±5%) 고객 수: 100만원 경계 {near_1m}명, 30만원 경계 {near_300k}명")

    # 적립률 가정표 (예산 추정)
    accrual_rate = {"실버": 0.01, "골드": 0.02, "VIP": 0.03}
    print("\n[예산 가정: 등급별 적립률] 실버 1% / 골드 2% / VIP 3%")
    for name, summary in [("안A", summary_a), ("안B", summary_b)]:
        budget = sum(summary.loc[g, "매출합"] * accrual_rate[g] for g in accrual_rate)
        print(f"  {name} 총 예상 적립 예산: {budget:,.0f} 원")

    print(
        "\n권고: 안A(비율 기준)는 인원 구성이 매 시즌 안정적으로 유지되어 예산 예측이 쉬운 "
        "반면, 안B(금액 기준)는 전체 매출이 늘어날수록 상위 등급 인원이 자연 증가해 예산이 "
        "불안정해질 수 있습니다. 인원·예산 안정성을 우선한다면 안A를 권고합니다."
    )
    return compare


if __name__ == "__main__":
    rfm = problem_03()
    problem_04(rfm)
