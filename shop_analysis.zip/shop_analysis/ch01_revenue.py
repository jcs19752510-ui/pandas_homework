# -*- coding: utf-8 -*-
"""
1장. 매출 성과 진단과 채널 리포트
  문제 01: 신뢰할 수 있는 매출 원장 만들기
  문제 02: 상반기 성장 기여 분해 브리핑
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger


def problem_01():
    print("\n########## 문제 01: 신뢰할 수 있는 매출 원장 만들기 ##########")
    result = build_net_sales_ledger(verbose=True)
    gross = result["gross_ledger"]
    net = result["net_ledger"]

    # 월별 총매출/순매출/취소반품 제외액/유효 주문수 대사표
    gross_m = gross.copy()
    gross_m["month"] = gross_m["order_datetime"].dt.to_period("M")
    net_m = net.copy()
    net_m["month"] = net_m["order_datetime"].dt.to_period("M")

    monthly_gross = gross_m.groupby("month")["line_amount"].sum().rename("총매출")
    monthly_net = net_m.groupby("month")["line_amount"].sum().rename("순매출")
    monthly_excluded = (monthly_gross - monthly_net).rename("취소_반품_제외액")
    monthly_valid_orders = net_m.groupby("month")["order_id"].nunique().rename("유효_주문수")

    reconciliation = pd.concat(
        [monthly_gross, monthly_net, monthly_excluded, monthly_valid_orders], axis=1
    )
    print("\n[월별 대사표] (총매출/순매출/취소·반품 제외액/유효 주문수)")
    print(reconciliation.round(0).to_string())

    print(
        "\n매출 정의 문서화: "
        "본 원장은 order_items 를 완전 중복 제거하고 order_datetime 파싱 실패(빈 문자열 등) "
        "및 2024년 상반기 기간 밖 행을 제거한 뒤, canceled/returned 상태를 뺀 값을 '순매출'로, "
        "전체 상태를 포함한 값을 '총매출'로 정의한다. 재무팀·마케팅팀의 수치 차이는 상태 포함 "
        "범위(취소/반품 처리 여부)의 차이에서 비롯된 것으로 확인된다."
    )
    return net


def problem_02(net_ledger: pd.DataFrame = None):
    print("\n########## 문제 02: 상반기 성장 기여 분해 브리핑 ##########")
    if net_ledger is None:
        net_ledger = build_net_sales_ledger(verbose=False)["net_ledger"]

    df = net_ledger.copy()
    df["month"] = df["order_datetime"].dt.to_period("M")

    # 월별 순매출, 구매고객수, 주문수
    monthly_sales = df.groupby("month")["line_amount"].sum()
    monthly_customers = df.groupby("month")["customer_id"].nunique()
    monthly_orders = df.groupby("month")["order_id"].nunique()

    decomposition = pd.DataFrame({
        "구매고객수": monthly_customers,
        "고객당_주문수": monthly_orders / monthly_customers,
        "AOV": monthly_sales / monthly_orders,
        "순매출": monthly_sales,
    })
    # 검산: 구매고객수 x 고객당주문수 x AOV == 순매출
    decomposition["검산_순매출"] = (
        decomposition["구매고객수"] * decomposition["고객당_주문수"] * decomposition["AOV"]
    )
    decomposition["검산_오차"] = (decomposition["검산_순매출"] - decomposition["순매출"]).abs()
    assert (decomposition["검산_오차"] < 1e-6).all(), "분해 항등식 검산 실패"

    print("\n[월별 성장 분해표]")
    print(decomposition.round(2).to_string())

    jan, jun = decomposition.iloc[0], decomposition.iloc[-1]
    growth = {
        "구매고객수_변화율": jun["구매고객수"] / jan["구매고객수"] - 1,
        "고객당_주문수_변화율": jun["고객당_주문수"] / jan["고객당_주문수"] - 1,
        "AOV_변화율": jun["AOV"] / jan["AOV"] - 1,
    }
    print("\n[1월 대비 6월 요인별 변화율]")
    for k, v in growth.items():
        print(f"  {k}: {v:+.1%}")

    # 로그 분해로 기여 비중 100% 산출 (곱셈 항등식의 로그는 덧셈 항등식이 됨)
    log_growth = {k: np.log(1 + v) for k, v in growth.items()}
    total_log = sum(log_growth.values())
    contribution = {k: v / total_log for k, v in log_growth.items()}
    print("\n[요인별 성장 기여 비중] (로그 분해, 합=100%)")
    for k, v in contribution.items():
        print(f"  {k}: {v:.1%}")

    main_driver = max(growth, key=growth.get)
    print(f"\n결론: 상반기 성장의 주된 동력은 '{main_driver}' 입니다.")
    return decomposition


if __name__ == "__main__":
    net = problem_01()
    problem_02(net)
