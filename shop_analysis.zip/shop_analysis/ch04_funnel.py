# -*- coding: utf-8 -*-
"""
4장. 퍼널과 전환 분석
  문제 08: 세션 퍼널 구축과 단계별 이탈
  문제 09: 요일x시간대 전환 패턴과 광고 시간 최적화
  문제 10: 행동 로그와 주문 데이터 대사
"""
import pandas as pd
import numpy as np
from common import load_web_logs, valid_orders_only


def problem_08():
    print("\n########## 문제 08: 세션 퍼널 구축과 단계별 이탈 ##########")
    logs = load_web_logs(
        usecols=["event_type", "session_id"],
        dtype={"event_type": "category", "session_id": "string"},
    )

    # 세션당 같은 이벤트가 여러 번 찍히므로, "도달 여부"만 남긴다
    reach = logs.drop_duplicates(subset=["session_id", "event_type"])
    reach_matrix = pd.crosstab(reach["session_id"], reach["event_type"])
    reach_matrix = (reach_matrix > 0).astype(int)

    n_sessions = len(reach_matrix)
    n_view = reach_matrix.get("view", pd.Series(dtype=int)).sum()
    n_cart = reach_matrix.get("cart", pd.Series(dtype=int)).sum()
    n_purchase = reach_matrix.get("purchase", pd.Series(dtype=int)).sum()

    funnel = pd.DataFrame({
        "단계": ["view", "cart", "purchase"],
        "도달_세션수": [n_view, n_cart, n_purchase],
    })
    funnel["전체세션대비_비율"] = funnel["도달_세션수"] / n_sessions
    print(f"\n전체 세션수: {n_sessions:,}")
    print("\n[퍼널 도달표]")
    print(funnel.round(3).to_string(index=False))

    view_to_cart = n_cart / n_view
    cart_to_purchase = n_purchase / n_cart
    view_to_purchase = n_purchase / n_view
    print(f"\nview->cart 전환율: {view_to_cart:.1%}")
    print(f"cart->purchase 전환율: {cart_to_purchase:.1%}")
    print(f"정규경로 전체 전환율(view->purchase): {view_to_purchase:.1%}")

    # 장바구니 없이 바로 구매한 세션 비중
    direct_purchase = ((reach_matrix.get("purchase", 0) == 1) & (reach_matrix.get("cart", 0) == 0)).sum()
    print(f"\n장바구니 없이 바로 구매한 세션: {direct_purchase:,}건 "
          f"(전체 구매 세션의 {direct_purchase / n_purchase:.1%})")

    bottleneck = "view->cart" if view_to_cart < cart_to_purchase else "cart->purchase"
    print(f"\n가장 큰 이탈 단계: {bottleneck}")
    print("개선 실험 아이디어: "
          "① 상품 상세 페이지에 '장바구니 담기' 버튼을 스티키(고정)로 노출해 이탈 감소 유도, "
          "② 장바구니 진입 후 이탈 세션 대상 리마인드 배너/쿠폰 노출 A/B 테스트")
    return funnel


def problem_09():
    print("\n########## 문제 09: 요일x시간대 전환 패턴과 광고 시간 최적화 ##########")
    logs = load_web_logs(
        usecols=["event_type", "event_time", "session_id"],
        dtype={"event_type": "category", "session_id": "string"},
    )
    session_start = logs.groupby("session_id")["event_time"].min().rename("start_time")
    session_purchase = (
        logs[logs["event_type"] == "purchase"].groupby("session_id").size() > 0
    ).rename("converted")

    sessions = pd.concat([session_start], axis=1).join(session_purchase, how="left")
    sessions["converted"] = sessions["converted"].fillna(False)
    sessions["dow"] = sessions["start_time"].dt.dayofweek  # 0=월요일
    sessions["hour"] = sessions["start_time"].dt.hour

    hourly = sessions.groupby("hour").agg(세션수=("converted", "size"), 전환율=("converted", "mean"))
    print("\n[시간대별 세션수·전환율 프로파일]")
    print(hourly.round(3).to_string())

    pivot_sessions = sessions.pivot_table(index="dow", columns="hour", values="converted", aggfunc="size", fill_value=0)
    pivot_conv = sessions.pivot_table(index="dow", columns="hour", values="converted", aggfunc="mean")
    print("\n[요일x시간대 세션수 피벗] (0=월 ... 6=일)")
    print(pivot_sessions.to_string())
    print("\n[요일x시간대 전환율 피벗]")
    print(pivot_conv.round(3).to_string())

    # 최소 표본 기준: 새벽 등 표본이 적어 튀는 셀 제외
    MIN_SAMPLE = 200
    stable_hourly = hourly[hourly["세션수"] >= MIN_SAMPLE]
    top_traffic = stable_hourly["세션수"].idxmax()
    top_conv = stable_hourly["전환율"].idxmax()
    print(f"\n(최소표본 {MIN_SAMPLE}세션 이상 시간대만 사용)")
    print(f"트래픽 최상위 시간대: {top_traffic}시 / 전환율 최상위 시간대: {top_conv}시")
    if top_traffic == top_conv:
        print("두 지표가 같은 시간대를 가리키므로 그 시간대에 입찰을 강화하는 것이 합리적입니다.")
    else:
        print("트래픽이 많은 시간과 전환이 잘 되는 시간이 달라, 트래픽만 보고 입찰하면 "
              "비효율이 발생할 수 있습니다. 전환율 상위 시간대 중심으로 입찰 강화를 제안합니다.")
    return hourly, pivot_conv


def problem_10():
    print("\n########## 문제 10: 행동 로그와 주문 데이터 대사 ##########")
    logs = load_web_logs(
        usecols=["event_type", "event_time", "customer_id"],
        dtype={"event_type": "category"},
    )
    orders = valid_orders_only()

    purchase_logs = logs[(logs["event_type"] == "purchase") & (logs["customer_id"].notna())].copy()
    print(f"customer_id 결측 purchase 로그(대사 불가, 별도 계상): "
          f"{(logs['event_type']=='purchase').sum() - len(purchase_logs):,}건")

    web_orders = orders[orders["channel"] == "web"].copy()
    print("※ web_logs는 사이트 행동 기록이므로 store/app 주문과 직접 대조하는 것은 무의미합니다. "
          "따라서 orders를 channel=='web'으로 한정해 대조합니다.")

    print(f"\n[총량 대조] web_logs purchase 이벤트수: {len(purchase_logs):,}건 / "
          f"web 채널 유효 주문수: {len(web_orders):,}건")
    print(f"web_logs purchase 고유고객수: {purchase_logs['customer_id'].nunique():,}명 / "
          f"web 채널 유효 주문 고유고객수: {web_orders['customer_id'].nunique():,}명")

    # 월별 대조
    purchase_logs["month"] = purchase_logs["event_time"].dt.to_period("M")
    web_orders["month"] = web_orders["order_datetime"].dt.to_period("M")
    monthly_compare = pd.DataFrame({
        "로그_purchase건수": purchase_logs.groupby("month").size(),
        "web_유효주문수": web_orders.groupby("month").size(),
    })
    print("\n[월별 대조]")
    print(monthly_compare.to_string())

    # 고객x일 단위 병합으로 해상도를 높여 유실/과다 규모 추정
    purchase_logs["date"] = purchase_logs["event_time"].dt.date
    web_orders["date"] = web_orders["order_datetime"].dt.date
    log_cust_date = purchase_logs[["customer_id", "date"]].drop_duplicates()
    order_cust_date = web_orders[["customer_id", "date"]].drop_duplicates()
    merged = log_cust_date.merge(order_cust_date, on=["customer_id", "date"], how="outer", indicator=True)

    only_log = (merged["_merge"] == "left_only").sum()
    only_order = (merged["_merge"] == "right_only").sum()
    both = (merged["_merge"] == "both").sum()
    print(f"\n[고객x일 단위 병합 결과] 로그에만 있음: {only_log:,} / 주문에만 있음: {only_order:,} / "
          f"둘 다 있음: {both:,}")

    loss_rate = only_order / (only_order + both)
    print(f"\n로그 유실 추정치(주문은 있는데 로그에 없는 비율): {loss_rate:.1%}")
    print("\n[로그 기반 지표 사용 가이드라인]")
    print("  1) 로그 전환율은 '방향성 지표'로만 쓰고, 절대 매출 수치는 반드시 주문 데이터로 검증한다.")
    print("  2) customer_id 결측 로그(비로그인 방문)는 대사 대상에서 제외되어 있어 실제 유실률은 "
          "이보다 낮을 수 있음을 함께 보고한다.")
    print("  3) app/store 채널의 행동은 web_logs로 설명할 수 없으므로 채널별 지표를 섞어 쓰지 않는다.")
    return monthly_compare


if __name__ == "__main__":
    problem_08()
    problem_09()
    problem_10()
