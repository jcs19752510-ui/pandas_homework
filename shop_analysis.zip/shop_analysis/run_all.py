# -*- coding: utf-8 -*-
"""
run_all.py
==========
판다스 실무 마케팅 문제 30제 - 전체 실행 스크립트

사용법:
  1) pip install pandas numpy pyarrow
  2) python generate_shop_data.py   (data/ 폴더에 CSV 5개 생성. 원본 데이터가 이미 있다면
     그 CSV들을 data/ 폴더에 넣기만 하고 이 단계는 건너뛰어도 됩니다)
  3) python run_all.py              (30문제 전부 순서대로 실행, 콘솔에 결과 출력)

특정 장만 실행하고 싶다면 예를 들어:
    python ch03_cohort.py
처럼 해당 파일만 단독 실행해도 됩니다 (각 파일에 if __name__ == "__main__" 있음).
"""
import sys
import traceback

CHAPTERS = [
    ("1장 매출 성과 진단과 채널 리포트", "ch01_revenue"),
    ("2장 고객 세분화(RFM)", "ch02_rfm"),
    ("3장 코호트와 리텐션 분석", "ch03_cohort"),
    ("4장 퍼널과 전환 분석", "ch04_funnel"),
    ("5장 상품 포트폴리오와 MD 전략", "ch05_product"),
    ("6장 가격과 할인 효과 분석", "ch06_discount"),
    ("7장 고객 생애가치와 이탈 관리", "ch07_ltv_churn"),
    ("8장 시계열 수요와 시즌성", "ch08_timeseries"),
    ("9장 비교 분석과 준실험적 사고", "ch09_comparison"),
    ("10장 대용량 로그 마케팅 파이프라인", "ch10_pipeline"),
]

if __name__ == "__main__":
    import importlib

    for title, module_name in CHAPTERS:
        print("\n" + "=" * 70)
        print(f"### {title} ###")
        print("=" * 70)
        try:
            module = importlib.import_module(module_name)
            # 각 모듈의 __main__ 블록에 있는 로직을 함수로도 쓸 수 있게,
            # 모듈에 정의된 problem_XX 함수들을 이름 순서대로 전부 실행합니다.
            problem_fns = sorted(
                [f for name, f in vars(module).items() if name.startswith("problem_")],
                key=lambda f: f.__name__,
            )
            for fn in problem_fns:
                try:
                    fn()
                except Exception:
                    print(f"\n[오류] {fn.__name__} 실행 중 예외 발생:")
                    traceback.print_exc()
        except Exception:
            print(f"\n[오류] {module_name} 모듈 로드 중 예외 발생:")
            traceback.print_exc()

    print("\n" + "=" * 70)
    print("전체 30문제 실행 완료")
    print("=" * 70)
