# -*- coding: utf-8 -*-
"""
9장. 비교 분석과 준실험적 사고
  문제 24: 앱 vs 웹 성과의 구성 보정 비교
  문제 25: 반품 경험이 재구매에 남기는 흔적
  문제 26: 할인 첫 구매 고객은 남는가
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, load_customers, load_orders, load_order_items, load_products


def problem_24():
    print("\n########## 문제 24: 앱 vs 웹 성과의 구성 보정 비교 ##########")
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    customers = load_customers()

    order_level = net.groupby(["order_id", "customer_id", "channel"])["line_amount"].sum().reset_index()

    # 1) 단순 비교
    simple = order_level.groupby("channel").agg(AOV=("line_amount", "mean"),
                                                  주문수=("order_id", "nunique"))
    freq = order_level.groupby(["channel", "customer_id"]).size().groupby("channel").mean().rename("고객당_주문수")
    simple = simple.join(freq)
    print("\n[단순 비교표] (보고서가 제기한 주장 재현)")
    print(simple.round(2).to_string())

    # 2) 연령대 부여
    ref_date = pd.Timestamp("2024-07-01")
    customers = customers.copy()
    customers["age"] = ((ref_date - customers["birth_date"]).dt.days / 365.25)
    customers["age_band"] = pd.cut(customers["age"], bins=[0, 20, 30, 40, 50, 200],
                                    labels=["10대이하", "20대", "30대", "40대", "50대이상"])
    n_missing_age = customers["birth_date"].isna().sum()
    print(f"\nbirth_date 결측 고객(연령 층화 대상 제외): {n_missing_age}명")

    order_level = order_level.merge(customers[["customer_id", "age_band"]], on="customer_id", how="left")
    n_excluded_orders = order_level["age_band"].isna().sum()
    print(f"연령대 미상으로 층화 비교에서 제외되는 주문: {n_excluded_orders}건")
    stratified_base = order_level.dropna(subset=["age_band"])

    # 채널별 연령 구성표
    age_composition = pd.crosstab(stratified_base["channel"], stratified_base["age_band"], normalize="index")
    print("\n[채널별 연령대 구성비]")
    print((age_composition * 100).round(1).to_string())

    # 3) 층화 비교
    strat_aov = stratified_base.groupby(["age_band", "channel"], observed=True)["line_amount"].mean().unstack()
    print("\n[연령대x채널 층화 AOV 비교표]")
    print(strat_aov.round(0).to_string())

    diff_by_age = strat_aov["app"] - strat_aov["web"] if "app" in strat_aov.columns and "web" in strat_aov.columns else None
    simpson = "역전 없음(단순비교 방향 유지)" if diff_by_age is not None and (diff_by_age > 0).all() else "일부/전체 역전 가능성 있음"
    print(f"\n심슨의 역설 점검: {simpson}")

    # 웹 연령 구성으로 앱 AOV 재가중 (구성 보정치)
    web_age_dist = age_composition.loc["web"] if "web" in age_composition.index else None
    if web_age_dist is not None and "app" in strat_aov.columns:
        adjusted_app_aov = (strat_aov["app"] * web_age_dist).sum()
        print(f"\n웹의 연령 구성으로 재가중한 앱 AOV(구성 보정치): {adjusted_app_aov:,.0f}원")
        print(f"단순 비교 앱 AOV: {simple.loc['app', 'AOV']:,.0f}원 / "
              f"단순 비교 웹 AOV: {simple.loc['web', 'AOV']:,.0f}원")
        gap_before = simple.loc["app", "AOV"] - simple.loc["web", "AOV"]
        gap_after = adjusted_app_aov - simple.loc["web", "AOV"]
        print(f"보정 전 격차: {gap_before:,.0f}원 -> 보정 후 격차: {gap_after:,.0f}원")
        conclusion = (
            "연령 구성을 통제한 뒤에도 앱의 AOV 우위가 상당 부분 유지된다면 채널 자체의 효과로 "
            "볼 수 있으나, 격차가 크게 줄어든다면 애초 관찰된 차이의 상당 부분이 '앱을 쓰는 "
            "고객층이 원래 더 소비력이 큰 연령대'라는 구성 차이에서 비롯된 것입니다."
        )
        print(f"\n수정된 결론: {conclusion}")
    return simple, strat_aov


def problem_25():
    print("\n########## 문제 25: 반품 경험이 재구매에 남기는 흔적 ##########")
    orders = load_orders().copy()
    orders["order_datetime"] = pd.to_datetime(orders["order_datetime"], errors="coerce")
    orders = orders.dropna(subset=["order_datetime"])
    orders = orders[orders["order_datetime"].between(pd.Timestamp("2024-01-01"), pd.Timestamp("2024-06-30 23:59:59"))]

    h1_window = orders[orders["order_datetime"] < pd.Timestamp("2024-05-01")]

    # 반품 경험군: 1~4월 중 첫 returned 주문
    returned = h1_window[h1_window["status"] == "returned"].sort_values("order_datetime")
    first_return = returned.drop_duplicates(subset="customer_id", keep="first")[["customer_id", "order_datetime"]]
    first_return = first_return.rename(columns={"order_datetime": "anchor_dt"})
    first_return["group"] = "반품경험군"

    # 비교군: 1~4월 동안 returned가 전혀 없이 delivered 주문을 가진 고객
    returned_customers = set(h1_window.loc[h1_window["status"] == "returned", "customer_id"])
    delivered = h1_window[h1_window["status"] == "delivered"]
    control_pool = delivered[~delivered["customer_id"].isin(returned_customers)]
    # 고객별 무작위 1건 추출 (random_state=42로 재현성 확보)
    rng = np.random.default_rng(42)
    control_pool = control_pool.copy()
    control_pool["_rand"] = rng.random(len(control_pool))
    control_orders = (
        control_pool.sort_values("_rand")
        .drop_duplicates(subset="customer_id", keep="first")
    )
    control = control_orders[["customer_id", "order_datetime"]].rename(columns={"order_datetime": "anchor_dt"})
    control["group"] = "비교군"

    print(f"반품경험군: {len(first_return):,}명 / 비교군(층화 전): {len(control):,}명")
    print("※ 반품 발생 '시각'은 데이터에 없으므로, 반품 주문의 주문 시각을 프록시(대리 지표)로 "
          "사용합니다. 실제 반품 처리/체감 시점과는 차이가 있을 수 있습니다.")

    both = pd.concat([first_return, control])[["customer_id", "anchor_dt", "group"]]

    # 기준 시점 이전 유효 주문수(활동 수준) 계산
    valid_before = orders[~orders["status"].isin(["canceled"])]
    both = both.merge(valid_before[["customer_id", "order_datetime"]], on="customer_id", how="left")
    both = both[both["order_datetime"] < both["anchor_dt"]]
    activity = both.groupby(["customer_id", "group", "anchor_dt"]).size().rename("사전활동_주문수").reset_index()

    # 층화 전 비교
    def repurchase_rate(activity_df, all_orders):
        merged = activity_df.merge(
            all_orders[~all_orders["status"].isin(["canceled", "returned"])][["customer_id", "order_datetime"]],
            on="customer_id", how="left"
        )
        merged["repurchased"] = (
            (merged["order_datetime"] > merged["anchor_dt"]) &
            (merged["order_datetime"] <= merged["anchor_dt"] + pd.Timedelta(days=60))
        )
        return merged.groupby(["customer_id", "group"])["repurchased"].any().groupby("group").mean()

    before_strat = repurchase_rate(activity, orders)
    print("\n[층화 전 60일 재구매율]")
    print((before_strat * 100).round(1).to_string())

    # 활동 수준으로 층화 (사분위)
    activity["활동층"] = pd.qcut(activity["사전활동_주문수"].rank(method="first"), 4, labels=["Q1", "Q2", "Q3", "Q4"])
    after_strat_rate = (
        activity.merge(
            orders[~orders["status"].isin(["canceled", "returned"])][["customer_id", "order_datetime"]],
            on="customer_id", how="left"
        )
    )
    after_strat_rate["repurchased"] = (
        (after_strat_rate["order_datetime"] > after_strat_rate["anchor_dt"]) &
        (after_strat_rate["order_datetime"] <= after_strat_rate["anchor_dt"] + pd.Timedelta(days=60))
    )
    per_customer = after_strat_rate.groupby(["customer_id", "group", "활동층"])["repurchased"].any().reset_index()
    strat_table = per_customer.groupby(["활동층", "group"], observed=True)["repurchased"].mean().unstack()
    print("\n[활동수준 층화 후 60일 재구매율]")
    print((strat_table * 100).round(1).to_string())

    print(
        "\n판정: 층화 전 두 군의 재구매율 차이는 반품경험군이 애초에 더 활발한 구매자였다는 "
        "구성 차이가 섞여 있을 수 있습니다. 활동 수준으로 층화한 뒤에도 반품경험군의 재구매율이 "
        "낮게 유지된다면 '반품 경험이 이탈에 영향을 준다'는 CS팀 주장에 힘이 실리고, 차이가 "
        "사라진다면 애초 관찰된 차이는 활동성 차이였을 뿐입니다."
    )
    print("프록시의 한계: 반품 처리 완료 시점이 아닌 '반품으로 판정된 주문의 주문 시각'을 "
          "기준으로 삼았으므로, 실제 고객이 반품을 '경험'한(체감한) 시점과는 오차가 있습니다.")
    return before_strat, strat_table


def problem_26():
    print("\n########## 문제 26: 할인 첫 구매 고객은 남는가 ##########")
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    products = load_products()

    order_level = net.groupby(["customer_id", "order_id"]).agg(
        order_dt=("order_datetime", "max"),
        총수량=("quantity", "sum"),
    ).reset_index()
    order_level["할인강도"] = net.groupby(["customer_id", "order_id"]).apply(
        lambda g: (g["quantity"] * g["discount"]).sum() / g["quantity"].sum()
        if g["quantity"].sum() > 0 else g["discount"].mean()
    ).values

    first_purchase = order_level.groupby("customer_id")["order_dt"].min().rename("first_dt")
    order_level = order_level.merge(first_purchase, on="customer_id")
    first_orders = order_level[order_level["order_dt"] == order_level["first_dt"]].drop_duplicates("customer_id")

    # 1~3월 첫구매 고객만
    first_orders = first_orders[
        first_orders["first_dt"].dt.to_period("M").isin(
            [pd.Period("2024-01", "M"), pd.Period("2024-02", "M"), pd.Period("2024-03", "M")]
        )
    ].copy()

    first_orders["할인구간"] = pd.cut(
        first_orders["할인강도"], bins=[-0.001, 0, 0.10, 1.0], labels=["정가0%", "저할인0~10%", "고할인10%+"]
    )
    print("\n[구간별 표본수]")
    print(first_orders["할인구간"].value_counts().to_string())

    # 90일 재구매율
    all_orders = order_level[["customer_id", "order_dt"]]
    check = first_orders[["customer_id", "first_dt", "할인구간"]].merge(all_orders, on="customer_id")
    check["repurchased_90d"] = (
        (check["order_dt"] > check["first_dt"]) &
        (check["order_dt"] <= check["first_dt"] + pd.Timedelta(days=90))
    )
    repurchase_by_band = check.groupby(["customer_id", "할인구간"], observed=True)["repurchased_90d"].any() \
        .groupby("할인구간", observed=True).mean()
    print("\n[할인구간별 90일 재구매율] (용량-반응 기울기 확인)")
    print((repurchase_by_band * 100).round(1).to_string())

    # 재구매 고객의 재구매 주문 할인 이용률 (할인 의존 형성 여부)
    repeat_customers = check[check["repurchased_90d"]]["customer_id"].unique()
    repeat_orders = order_level[
        (order_level["customer_id"].isin(repeat_customers)) &
        (order_level["order_dt"] > order_level["first_dt"]) &
        (order_level["order_dt"] <= order_level["first_dt"] + pd.Timedelta(days=90))
    ].copy()
    repeat_orders["할인사용"] = repeat_orders["할인강도"] > 0
    repeat_orders = repeat_orders.merge(first_orders[["customer_id", "할인구간"]], on="customer_id")
    discount_usage = repeat_orders.groupby(["customer_id", "할인구간"], observed=True)["할인사용"].mean() \
        .groupby("할인구간", observed=True).mean()
    print("\n[구간별 재구매 주문 할인 이용률] (할인 의존 형성 여부)")
    print((discount_usage * 100).round(1).to_string())

    slope = repurchase_by_band.iloc[-1] - repurchase_by_band.iloc[0]
    print(f"\n용량-반응 기울기(고할인-정가): {slope:+.1%}")
    if slope < 0:
        conclusion = "할인 강도가 클수록 90일 재구매율이 낮아지는 경향이 관찰됩니다."
    else:
        conclusion = "할인 강도와 90일 재구매율 사이에 뚜렷한 음(-)의 관계는 관찰되지 않습니다."
    print(f"\n결론: {conclusion}")
    print(
        "조건부 권고: 정가(0%) 구간은 표본이 매우 작아 결과가 불안정할 수 있습니다. 카테고리 "
        "층화로 기울기의 강건성을 재확인한 뒤, 재구매율 하락이 뚜렷하지 않은 구간까지는 첫 구매 "
        "할인을 유지하되, 하락이 뚜렷해지는 구간부터는 할인 상한으로 설정할 것을 조건부로 "
        "권고합니다."
    )
    return repurchase_by_band, discount_usage


if __name__ == "__main__":
    problem_24()
    problem_25()
    problem_26()
