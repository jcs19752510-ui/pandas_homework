# -*- coding: utf-8 -*-
"""
5장. 상품 포트폴리오와 MD 전략
  문제 11: 카테고리 확대·유지·축소 매트릭스
  문제 12: 동시구매 분석과 번들 후보
  문제 13: 상품 마스터 이상 진단과 지표 영향
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, load_products, load_order_items


def problem_11():
    print("\n########## 문제 11: 카테고리 확대·유지·축소 매트릭스 ##########")
    result = build_net_sales_ledger(verbose=False)
    gross = result["gross_ledger"]   # 반품률 계산에 필요(취소 제외, 반품 포함)
    net = result["net_ledger"]       # 순매출/마진 계산용
    products = load_products()

    net = net.merge(products[["product_id", "category", "cost"]], on="product_id", how="left")
    net["margin"] = net["quantity"] * (net["unit_price"] * (1 - net["discount"]) - net["cost"])

    cat_sales = net.groupby("category").agg(순매출=("line_amount", "sum"), 마진액=("margin", "sum"))
    cat_sales["마진율"] = cat_sales["마진액"] / cat_sales["순매출"]

    # 반품률 = 반품 주문수 / (취소 제외 주문수)  -> gross(취소 포함) 중 canceled만 빼고 계산
    not_canceled = gross[gross["status"] != "canceled"].merge(
        products[["product_id", "category"]], on="product_id", how="left"
    )
    order_cat = not_canceled.drop_duplicates(subset=["order_id", "category"])
    returned_orders = order_cat[order_cat["status"] == "returned"].groupby("category")["order_id"].nunique()
    total_orders = order_cat.groupby("category")["order_id"].nunique()
    return_rate = (returned_orders / total_orders).rename("반품률").fillna(0)

    combined = cat_sales.join(return_rate)
    print("\n[카테고리 3지표 종합표]")
    print(combined.round(4).to_string())

    # 순위 점수 (매출·마진 클수록 좋음 / 반품률 작을수록 좋음)
    combined["rank_sales"] = combined["순매출"].rank(ascending=False)
    combined["rank_margin"] = combined["마진율"].rank(ascending=False)
    combined["rank_return"] = combined["반품률"].rank(ascending=True)

    weights = {"rank_sales": 0.4, "rank_margin": 0.4, "rank_return": 0.2}
    combined["종합점수"] = sum(combined[c] * w for c, w in weights.items())
    combined = combined.sort_values("종합점수")

    n = len(combined)
    combined["전략"] = pd.cut(
        combined["종합점수"].rank(method="first"),
        bins=[0, n / 3, 2 * n / 3, n],
        labels=["확대", "유지", "축소"],
    )
    print(f"\n[가중치] 매출 {weights['rank_sales']:.0%} / 마진 {weights['rank_margin']:.0%} / "
          f"반품(역방향) {weights['rank_return']:.0%}")
    print("\n[종합 점수 순위 및 전략 제안] (점수 낮을수록 우수)")
    print(combined[["순매출", "마진율", "반품률", "종합점수", "전략"]].round(3).to_string())

    sales_rank_order = combined.sort_values("rank_sales").index.tolist()
    total_rank_order = combined.sort_values("종합점수").index.tolist()
    changed = [c for i, c in enumerate(total_rank_order) if sales_rank_order[i] != c]
    print(f"\n매출 단독 순위와 종합 점수 순위가 달라진 카테고리(순위 변경 발생): {changed}")

    # 민감도: 반품 가중치를 0.4로 올려서 재확인
    weights2 = {"rank_sales": 0.3, "rank_margin": 0.3, "rank_return": 0.4}
    combined["종합점수_민감도"] = sum(combined[c] * w for c, w in weights2.items())
    print("\n[민감도] 반품 가중치를 20%->40%로 올린 재계산 순위")
    print(combined.sort_values("종합점수_민감도")[["종합점수_민감도"]].round(3).to_string())
    return combined


def problem_12():
    print("\n########## 문제 12: 동시구매 분석과 번들 후보 ##########")
    items = load_order_items()
    products = load_products()

    lines = items.merge(products[["product_id", "category"]], on="product_id", how="left")

    # 주문x카테고리 고유쌍으로 축약 후 self-merge (메모리 폭발 방지)
    order_cat = lines[["order_id", "category"]].drop_duplicates()
    pairs = order_cat.merge(order_cat, on="order_id", suffixes=("_A", "_B"))
    pairs = pairs[pairs["category_A"] < pairs["category_B"]]  # A==A 제거, (A,B)/(B,A) 중복 제거

    pair_counts = pairs.groupby(["category_A", "category_B"]).size().rename("동시구매주문수").reset_index()

    cat_order_count = order_cat.groupby("category")["order_id"].nunique()
    total_orders = order_cat["order_id"].nunique()

    pair_counts = pair_counts.merge(
        cat_order_count.rename("cnt_A"), left_on="category_A", right_index=True
    ).merge(cat_order_count.rename("cnt_B"), left_on="category_B", right_index=True)

    pair_counts["지지도"] = pair_counts["동시구매주문수"] / total_orders
    expected = (pair_counts["cnt_A"] / total_orders) * (pair_counts["cnt_B"] / total_orders)
    pair_counts["향상도"] = pair_counts["지지도"] / expected

    top_cat_pairs = pair_counts.sort_values("향상도", ascending=False).head(10)
    print("\n[카테고리 쌍 동시구매 상위표 (원지표+향상도)]")
    print(top_cat_pairs[["category_A", "category_B", "동시구매주문수", "지지도", "향상도"]]
          .round(4).to_string(index=False))

    # 상품 수준 동시구매 (상위 인기 상품군으로 범위를 좁혀 계산량 축소)
    top_products = items["product_id"].value_counts().head(60).index
    lines_top = lines[lines["product_id"].isin(top_products)]
    order_prod = lines_top[["order_id", "product_id"]].drop_duplicates()
    prod_pairs = order_prod.merge(order_prod, on="order_id", suffixes=("_A", "_B"))
    prod_pairs = prod_pairs[prod_pairs["product_id_A"] < prod_pairs["product_id_B"]]
    prod_pair_counts = (
        prod_pairs.groupby(["product_id_A", "product_id_B"]).size()
        .rename("동시구매주문수").reset_index().sort_values("동시구매주문수", ascending=False)
    )
    print("\n[상품 수준 상위 동시구매 쌍 - 번들 후보 3건]")
    print(prod_pair_counts.head(3).to_string(index=False))
    print("예상 효과 논리: 동시구매 빈도와 향상도가 모두 높은 조합은 우연한 동시 노출이 아니라 "
          "실제 사용 맥락이 연결된 조합일 가능성이 높아, 번들 할인 시 교차판매 상승이 기대됩니다.")
    return pair_counts


def problem_13():
    print("\n########## 문제 13: 상품 마스터 이상 진단과 지표 영향 ##########")
    products_raw = pd.read_csv("data/products.csv")
    items = load_order_items()

    price_numeric = pd.to_numeric(
        products_raw["price"].astype(str).str.replace(",", "", regex=False).str.replace("원", "", regex=False),
        errors="coerce",
    )

    is_missing = products_raw["price"].isna()
    is_format_error = price_numeric.isna() & ~is_missing
    is_zero = (price_numeric == 0)
    is_negative = (price_numeric < 0)

    anomaly_summary = pd.Series({
        "결측": is_missing.sum(),
        "형식오염(문자혼입)": is_format_error.sum(),
        "0원": is_zero.sum(),
        "음수": is_negative.sum(),
    })
    print("\n[이상 유형별 건수]")
    print(anomaly_summary.to_string())

    # 이상 상품이 실제로 팔린 단가와 대조
    anomaly_mask = is_missing | is_format_error | is_zero | is_negative
    anomaly_products = products_raw.loc[anomaly_mask, ["product_id", "product_name", "price", "cost"]]
    actual_sale_price = items.groupby("product_id")["unit_price"].mean().rename("실거래_평균단가")
    anomaly_check = anomaly_products.merge(actual_sale_price, on="product_id", how="left")
    print(f"\n이상 레코드 {len(anomaly_products)}건 중 실제 판매 이력이 있는 상품: "
          f"{anomaly_check['실거래_평균단가'].notna().sum()}건")
    print(anomaly_check.head(10).to_string(index=False))

    # 마스터 price 기준 vs 거래단가(unit_price) 기준 마진 차이
    products_raw["price_master"] = price_numeric
    merged = items.merge(products_raw[["product_id", "price_master", "cost"]], on="product_id", how="left")
    merged["margin_master"] = merged["quantity"] * (merged["price_master"] * (1 - merged["discount"]) - merged["cost"])
    merged["margin_actual"] = merged["quantity"] * (merged["unit_price"] * (1 - merged["discount"]) - merged["cost"])

    diff = pd.Series({
        "마스터_price_기준_총마진": merged["margin_master"].sum(),
        "실거래_단가_기준_총마진": merged["margin_actual"].sum(),
    })
    print("\n[두 기준 마진 차이]")
    print(diff.round(0).to_string())
    print(f"차이(마스터-실거래): {diff.iloc[0] - diff.iloc[1]:,.0f} 원")

    # 유효한데 역마진(진짜 역마진) 검출: 형식오류 아닌 정상 price인데 unit_price가 cost보다 낮은 경우
    valid_products = products_raw.loc[~anomaly_mask]
    real_margin_check = items.merge(valid_products[["product_id", "cost"]], on="product_id", how="inner")
    real_margin_check["real_negative"] = real_margin_check["unit_price"] * (1 - real_margin_check["discount"]) < real_margin_check["cost"]
    n_real_negative_lines = real_margin_check["real_negative"].sum()
    print(f"\n마스터 오류가 아닌데도 실제로 역마진(할인 후 판매가 < 원가)인 라인: "
          f"{n_real_negative_lines:,}건 (대부분 과도한 할인율에서 기인, 진짜 역마진)")

    priority = anomaly_summary.sort_values(ascending=False)
    print("\n[마스터 정비 우선순위] (건수 많은 순)")
    print(priority.to_string())
    return anomaly_summary


if __name__ == "__main__":
    problem_11()
    problem_12()
    problem_13()
