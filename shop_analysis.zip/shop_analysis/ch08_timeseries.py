# -*- coding: utf-8 -*-
"""
8장. 시계열 수요와 시즌성
  문제 21: 주간 매출 추세와 이동평균
  문제 22: 시간 단위 수요 프로파일과 피크 운영 계획
  문제 23: 7월 수요 나이브 예측과 한계 보고
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, valid_orders_only


def _daily_net_sales():
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    daily = net.set_index("order_datetime")["line_amount"].resample("D").sum()
    return daily


def problem_21():
    print("\n########## 문제 21: 주간 매출 추세와 이동평균 ##########")
    daily = _daily_net_sales()
    weekly = daily.resample("W-SUN").sum()
    weekly_ma4 = weekly.rolling(4).mean()

    table = pd.DataFrame({"주간매출": weekly, "4주이동평균": weekly_ma4})
    print("\n[주간 매출 및 4주 이동평균]")
    print(table.round(0).to_string())

    ma_valid = weekly_ma4.dropna()
    growth = ma_valid.iloc[-1] / ma_valid.iloc[0] - 1
    print(f"\n이동평균 기준 추세: {'상승' if growth > 0 else '하락'} / "
          f"상반기 성장률(이동평균 첫값 대비 마지막값): {growth:+.1%}")
    print(
        "\n보고 문구: 일별 매출은 요일 구성(주말/평일)과 무작위 변동 때문에 하루하루 톱니처럼 "
        "출렁입니다. 하루 등락에 반응해 '회복세'나 '꺾임'을 판단하면 잘못된 의사결정으로 "
        "이어지기 쉬우므로, 4주 이동평균처럼 노이즈를 걸러낸 지표로 추세를 판단해야 합니다."
    )
    return table


def problem_22():
    print("\n########## 문제 22: 시간 단위 수요 프로파일과 피크 운영 계획 ##########")
    orders = valid_orders_only()

    # 달력 시간축(연속) - 상반기 전체 시간대 수요 곡선
    hourly_calendar = orders.set_index("order_datetime")["order_id"].resample("h").nunique()
    print(f"\n달력 시간축 시점 수(참고): {len(hourly_calendar):,}개")

    # 하루 안의 시간축 (0~23시) - 평일/주말 나눠 '일수로 나눈 평균'
    orders = orders.copy()
    orders["hour"] = orders["order_datetime"].dt.hour
    orders["is_weekend"] = orders["order_datetime"].dt.dayofweek >= 5
    orders["date"] = orders["order_datetime"].dt.date

    n_weekday_days = orders.loc[~orders["is_weekend"], "date"].nunique()
    n_weekend_days = orders.loc[orders["is_weekend"], "date"].nunique()

    profile = orders.groupby(["is_weekend", "hour"])["order_id"].count().unstack(level=0, fill_value=0)
    profile.columns = ["평일_합계", "주말_합계"] if False else profile.columns
    profile = orders.pivot_table(index="hour", columns="is_weekend", values="order_id", aggfunc="count", fill_value=0)
    profile.columns = ["평일", "주말"]
    profile["평일_일평균"] = profile["평일"] / n_weekday_days
    profile["주말_일평균"] = profile["주말"] / n_weekend_days
    print("\n[시간대별 일평균 주문수 프로파일 (평일/주말)]")
    print(profile[["평일_일평균", "주말_일평균"]].round(2).to_string())

    # 채널별 피크 시간 층화
    by_channel = orders.pivot_table(index="hour", columns="channel", values="order_id", aggfunc="count", fill_value=0)
    print("\n[채널별 시간대 주문수]")
    print(by_channel.to_string())

    total_by_hour = profile["평일_일평균"] + profile["주말_일평균"]
    peak_threshold = total_by_hour.quantile(0.75)
    peak_hours = total_by_hour[total_by_hour >= peak_threshold].index.tolist()
    print(f"\n주문 피크 시간대(상위 25%): {sorted(peak_hours)}시")

    print(
        "\n운영 배치 제안: 피크 시간대에 CS 인력과 출고 마감 인원을 집중 배치하고, 비피크 시간대는 "
        "최소 인력으로 운영합니다.\n"
        "'주문 피크'(문제22, 실제 결제 완료 시점)와 문제09의 '세션 전환 피크'(방문이 구매로 이어지는 "
        "비율이 높은 시간)는 서로 다른 개념입니다. 세션 전환 피크는 광고 입찰의 효율을 보는 지표이고, "
        "주문 피크는 실제 운영 인력 수요를 보는 지표이므로, 두 지표가 가리키는 시간대가 다를 수 있고 "
        "각자의 목적에 맞게 따로 사용해야 합니다."
    )
    return profile


def problem_23():
    print("\n########## 문제 23: 7월 수요 나이브 예측과 한계 보고 ##########")
    daily = _daily_net_sales()
    monthly = daily.resample("MS").sum()

    # A안: 최근 3개월 평균 월간 성장률 외삽
    recent3 = monthly.iloc[-3:]
    growth_rates = recent3.pct_change().dropna()
    avg_growth = growth_rates.mean()
    forecast_a = monthly.iloc[-1] * (1 + avg_growth)
    print(f"\nA안(최근 3개월 평균 성장률 외삽): 평균 성장률 {avg_growth:+.1%}, "
          f"7월 전망치 {forecast_a:,.0f}원")

    # B안: 6월 요일별 일평균 x 7월 달력 요일구성
    june_daily = daily["2024-06"]
    dow_avg = june_daily.groupby(june_daily.index.dayofweek).mean()
    july_dates = pd.date_range("2024-07-01", "2024-07-31", freq="D")
    forecast_b = sum(dow_avg[d.dayofweek] for d in july_dates)
    print(f"B안(6월 요일별 일평균 x 7월 요일구성): 7월 전망치 {forecast_b:,.0f}원")

    print(f"\n두 안의 차이: {forecast_a - forecast_b:,.0f}원 "
          f"({(forecast_a / forecast_b - 1):+.1%})")
    print("A안 가정: 최근 성장 추세가 7월에도 그대로 이어진다.")
    print("B안 가정: 7월 수요 수준이 6월과 유사하며, 요일 구성 차이만 반영하면 된다.")

    # 백테스트: 1~5월로 6월 예측 후 실제와 비교
    train = daily["2024-01":"2024-05"]
    train_monthly = train.resample("MS").sum()
    actual_june = daily["2024-06"].sum()

    bt_recent3 = train_monthly.iloc[-3:]
    bt_growth = bt_recent3.pct_change().dropna().mean()
    bt_forecast_a = train_monthly.iloc[-1] * (1 + bt_growth)
    err_a = abs(bt_forecast_a - actual_june) / actual_june

    may_daily = train["2024-05"]
    dow_avg_may = may_daily.groupby(may_daily.index.dayofweek).mean()
    june_dates = pd.date_range("2024-06-01", "2024-06-30", freq="D")
    bt_forecast_b = sum(dow_avg_may[d.dayofweek] for d in june_dates)
    err_b = abs(bt_forecast_b - actual_june) / actual_june

    print(f"\n[백테스트: 1~5월로 6월 예측]")
    print(f"실제 6월 순매출: {actual_june:,.0f}원")
    print(f"A안(성장률 외삽) 예측: {bt_forecast_a:,.0f}원, 오차율: {err_a:.1%}")
    print(f"B안(요일 프로파일) 예측: {bt_forecast_b:,.0f}원, 오차율: {err_b:.1%}")

    better = "A안" if err_a < err_b else "B안"
    chosen_forecast = forecast_a if better == "A안" else forecast_b
    margin = 0.1  # 낙관/보수 구간 폭 가정
    print(f"\n권고안: 백테스트 오차가 더 작은 {better}을 채택합니다.")
    print(f"7월 전망 구간: 보수 {chosen_forecast * (1 - margin):,.0f}원 ~ "
          f"낙관 {chosen_forecast * (1 + margin):,.0f}원 (±{margin:.0%} 가정)")
    return {"forecast_a": forecast_a, "forecast_b": forecast_b, "err_a": err_a, "err_b": err_b}


if __name__ == "__main__":
    problem_21()
    problem_22()
    problem_23()
