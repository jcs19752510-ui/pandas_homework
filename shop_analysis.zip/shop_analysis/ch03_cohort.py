# -*- coding: utf-8 -*-
"""
3장. 코호트와 리텐션 분석
  문제 05: 첫 구매 코호트 리텐션 매트릭스
  문제 06: 2회차 구매 전환율 개선 과제
  문제 07: 상·하반기 신규 코호트 질 비교
"""
import pandas as pd
import numpy as np
from common import valid_orders_only, build_net_sales_ledger, load_products


def problem_05():
    print("\n########## 문제 05: 첫 구매 코호트 리텐션 매트릭스 ##########")
    orders = valid_orders_only()

    orders = orders.copy()
    orders["order_month"] = orders["order_datetime"].dt.to_period("M")
    first_month = orders.groupby("customer_id")["order_month"].min().rename("cohort")
    orders = orders.merge(first_month, on="customer_id")
    orders["period_n"] = (orders["order_month"] - orders["cohort"]).apply(lambda x: x.n)

    pivot_counts = orders.pivot_table(
        index="cohort", columns="period_n", values="customer_id", aggfunc="nunique"
    )
    cohort_size = orders.groupby("cohort")["customer_id"].nunique()
    retention = pivot_counts.div(cohort_size, axis=0)

    # 관측이 끝나지 않은 셀(우하단 삼각형)은 0이 아니라 결측이어야 함
    # -> pivot_table에서 해당 조합 자체가 존재하지 않으면 이미 NaN으로 남음(정상)
    print("\n[코호트 x 경과월 리텐션율 매트릭스] (행: 첫구매월, 열: M+n)")
    print((retention * 100).round(1).to_string())

    m1 = retention.get(1)
    print("\n[M+1 리텐션 코호트별 추이]")
    if m1 is not None:
        print((m1 * 100).round(1).to_string())
    print(
        "\n해석: 표의 우하단 빈칸(예: 6월 코호트의 M+1)은 '재구매율 0%'가 아니라 아직 그 "
        "시점의 데이터 자체가 존재하지 않는 관측 미완료 셀입니다. 0으로 채워 평균을 내면 "
        "최근 코호트의 리텐션이 부당하게 낮아 보이므로 반드시 결측으로 남겨야 합니다."
    )
    return orders, retention


def problem_06():
    print("\n########## 문제 06: 2회차 구매 전환율 개선 과제 ##########")
    orders = valid_orders_only().sort_values(["customer_id", "order_datetime"])
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    products = load_products()

    orders["order_seq"] = orders.groupby("customer_id").cumcount()
    first_orders = orders[orders["order_seq"] == 0].copy()
    second_orders = orders[orders["order_seq"] == 1][["customer_id", "order_datetime"]].rename(
        columns={"order_datetime": "second_dt"}
    )

    # 6월 첫구매 고객은 30일 관찰창을 채울 수 없어 제외
    first_orders["first_month"] = first_orders["order_datetime"].dt.to_period("M")
    eligible = first_orders[first_orders["first_month"] != pd.Period("2024-06", freq="M")].copy()
    n_excluded = (first_orders["first_month"] == pd.Period("2024-06", freq="M")).sum()
    print(f"6월 첫구매 고객 {n_excluded:,}명은 30일 관찰창 미충족으로 제외합니다.")

    eligible = eligible.merge(second_orders, on="customer_id", how="left")
    eligible["converted_30d"] = (
        (eligible["second_dt"] - eligible["order_datetime"]).dt.days <= 30
    ).fillna(False)

    # 첫 주문 라인에 할인 여부, 대표 카테고리 부여
    first_lines = net.merge(
        eligible[["customer_id", "order_datetime"]], on=["customer_id", "order_datetime"], how="inner"
    )
    first_lines = first_lines.merge(products[["product_id", "category"]], on="product_id", how="left")
    line_summary = first_lines.groupby("customer_id").agg(
        has_discount=("discount", lambda s: (s > 0).any()),
        category=("category", "first"),
    )
    eligible = eligible.merge(line_summary, on="customer_id", how="left")
    eligible["discount_flag"] = eligible["has_discount"].map({True: "할인", False: "정가"})

    by_channel = eligible.groupby("channel")["converted_30d"].mean()
    by_category = eligible.groupby("category")["converted_30d"].mean()
    by_discount = eligible.groupby("discount_flag")["converted_30d"].mean()

    print("\n[채널별 30일 2회차 전환율]")
    print((by_channel * 100).round(1).to_string())
    print("\n[카테고리별 30일 2회차 전환율]")
    print((by_category * 100).round(1).to_string())
    print("\n[할인여부별 30일 2회차 전환율]")
    print((by_discount * 100).round(1).to_string())

    worst = by_category.idxmin()
    print(
        f"\n개선 과제: 카테고리 '{worst}' 첫 구매 고객의 2회차 전환율이 가장 낮습니다. "
        "가설: 해당 카테고리는 재구매 주기가 길거나(예: 내구재), 첫 구매 만족도 확인이 "
        "안 되어 후속 유입 트리거(리마인드 쿠폰 등)가 부족할 수 있습니다."
    )
    return eligible


def problem_07():
    print("\n########## 문제 07: 상·하반기 신규 코호트 질 비교 ##########")
    net = build_net_sales_ledger(verbose=False)["net_ledger"]

    order_level = net.groupby(["customer_id", "order_id"]).agg(
        order_dt=("order_datetime", "max"),
        order_amount=("line_amount", "sum"),
        channel=("channel", "first"),
    ).reset_index()

    first_purchase = order_level.groupby("customer_id")["order_dt"].min().rename("first_dt")
    order_level = order_level.merge(first_purchase, on="customer_id")

    cohort_a = order_level[
        order_level["first_dt"].dt.to_period("M").isin(
            [pd.Period("2024-01", "M"), pd.Period("2024-02", "M")]
        )
    ].copy()
    cohort_b = order_level[
        order_level["first_dt"].dt.to_period("M").isin(
            [pd.Period("2024-04", "M"), pd.Period("2024-05", "M")]
        )
    ].copy()
    cohort_a["cohort"] = "A(1~2월)"
    cohort_b["cohort"] = "B(4~5월)"
    both = pd.concat([cohort_a, cohort_b])

    def window_metrics(df, days):
        d = df[(df["order_dt"] - df["first_dt"]).dt.days.between(0, days)]
        g = d.groupby("cohort").agg(
            누적순매출=("order_amount", "sum"),
            주문수=("order_id", "nunique"),
            고객수=("customer_id", "nunique"),
        )
        g["재구매율"] = (d.groupby("cohort")["customer_id"].apply(
            lambda s: (s.value_counts() > 1).mean()
        ))
        g["AOV"] = g["누적순매출"] / g["주문수"]
        return g

    fair = window_metrics(both, 30)  # 동일 관찰창(30일)
    biased = window_metrics(both, 10_000)  # 편향된 비교: 관찰창 없이 전체 누적

    print("\n[동일 관찰창(30일) 비교 - 공정한 비교]")
    print(fair.round(2).to_string())
    print("\n[관찰창 없이 전체 기간 누적 - 편향된 비교(대조용)]")
    print(biased.round(2).to_string())
    print(
        "\n※ 편향된 비교에서는 A코호트가 단순히 더 오래 관측되었기 때문에 누적 지표가 커 "
        "보입니다. 반드시 동일 관찰창(30일)으로 맞춘 위 표를 기준으로 판단해야 합니다."
    )

    # 채널 구성 차이로 재확인
    channel_strat = window_metrics(both, 30)
    by_channel = both[(both["order_dt"] - both["first_dt"]).dt.days.between(0, 30)]
    strat = by_channel.groupby(["cohort", "channel"]).agg(
        누적순매출=("order_amount", "sum"), 고객수=("customer_id", "nunique")
    )
    print("\n[채널별 층화 재확인]")
    print(strat.round(2).to_string())

    if "A(1~2월)" in fair.index and "B(4~5월)" in fair.index:
        aov_a, aov_b = fair.loc["A(1~2월)", "AOV"], fair.loc["B(4~5월)", "AOV"]
        verdict = "유지됨" if abs(aov_a - aov_b) / aov_a < 0.1 else "달라짐"
        print(f"\n판정: 동일 관찰창 기준 AOV 차이는 {(aov_b/aov_a - 1):+.1%} 수준으로, "
              f"신규 코호트의 질은 대체로 {verdict}으로 판단됩니다.")
    else:
        print("\n[안내] 이번 실행 데이터에는 두 코호트(A/B) 중 하나가 비어 있어 판정을 생략합니다. "
              "실제 책 데이터(신규 고객이 매달 고르게 유입되는 데이터)에서는 두 코호트가 모두 "
              "존재하며 위와 동일한 로직으로 비교됩니다.")
    return fair, biased


if __name__ == "__main__":
    problem_05()
    problem_06()
    problem_07()
