# -*- coding: utf-8 -*-
"""
6장. 가격과 할인 효과 분석
  문제 14: 할인율 구간별 손익 분석
  문제 15: 할인 의존 상품 검출
  문제 16: 할인 마진 잠식 시뮬레이션
"""
import pandas as pd
import numpy as np
from common import build_net_sales_ledger, load_products, load_order_items


def _net_with_margin():
    net = build_net_sales_ledger(verbose=False)["net_ledger"]
    products = load_products().drop_duplicates(subset=["product_id"])  # 완전 중복 상품 행 제거
    net = net.merge(products[["product_id", "category", "cost"]], on="product_id", how="left")
    net["sale_price"] = net["unit_price"] * (1 - net["discount"])
    net["margin"] = net["quantity"] * (net["sale_price"] - net["cost"])
    return net


def problem_14():
    print("\n########## 문제 14: 할인율 구간별 손익 분석 ##########")
    net = _net_with_margin()

    bins = [-0.001, 0, 0.10, 0.20, 1.0]
    labels = ["정가(0%)", "0~10%", "10~20%", "20%초과"]
    net["discount_band"] = pd.cut(net["discount"], bins=bins, labels=labels)

    band_summary = net.groupby("discount_band", observed=True).agg(
        판매수량=("quantity", "sum"),
        순매출=("line_amount", "sum"),
        마진액=("margin", "sum"),
    )
    band_summary["마진율"] = band_summary["마진액"] / band_summary["순매출"]
    band_summary["평균판매단가"] = band_summary["순매출"] / band_summary["판매수량"]
    print("\n[할인구간 x (수량,순매출,마진액,마진율,평균판매단가)]")
    print(band_summary.round(3).to_string())

    print(
        "\n관찰: 할인 구간이 깊어질수록 평균 판매단가는 낮아지고 판매 수량은 늘어나는 패턴이 "
        "관찰됩니다. 다만 이는 '할인이 수량을 늘렸다'는 인과가 아니라, 원래 잘 팔리는(수요가 "
        "큰) 상품이 할인 대상으로 자주 선택되었을 가능성과 뒤섞인 관찰적 상관일 뿐입니다."
    )
    worst_band = band_summary["마진율"].idxmin()
    print(f"\n마진 관점 가장 비효율적인 구간: {worst_band}")
    print("정책 제안: 20% 초과 할인은 마진율 훼손이 가장 크므로, 상시 할인이 아닌 한정 프로모션 "
          "용도로만 제한하고, 상시 할인은 0~10% 구간 내에서 운영할 것을 제안합니다.")
    return band_summary


def problem_15():
    print("\n########## 문제 15: 할인 의존 상품 검출 ##########")
    items = load_order_items()
    products = load_products()

    items["is_discount"] = items["discount"] > 0
    per_product = items.groupby("product_id").apply(
        lambda g: pd.Series({
            "할인수량": g.loc[g["is_discount"], "quantity"].sum(),
            "전체수량": g["quantity"].sum(),
            "가중평균할인율": (g["quantity"] * g["discount"]).sum() / g["quantity"].sum()
            if g["quantity"].sum() > 0 else g["discount"].mean(),
        })
    )
    per_product["할인판매비중"] = per_product["할인수량"] / per_product["전체수량"]

    print("\n[할인 판매 비중 분포]")
    print(per_product["할인판매비중"].describe().round(3).to_string())

    MIN_QTY = 100  # 최소 판매량 컷 (표본 적은 상품 제외)
    dependent = per_product[
        (per_product["할인판매비중"] >= 0.80) & (per_product["전체수량"] >= MIN_QTY)
    ].sort_values("할인판매비중", ascending=False)
    dependent = dependent.merge(products[["product_id", "product_name"]], left_index=True, right_on="product_id")
    print(f"\n[할인 의존 상품 목록] (할인비중>=80%, 전체수량>={MIN_QTY}) - {len(dependent)}개")
    print(dependent[["product_id", "product_name", "할인판매비중", "가중평균할인율", "전체수량"]]
          .round(3).head(20).to_string(index=False))

    # 정가 판매 실적 대조. 표본 부족 상품은 '대조 불가'
    MIN_FULL_PRICE_QTY = 5
    per_product["정가수량"] = per_product["전체수량"] - per_product["할인수량"]
    dependent_full = per_product.loc[dependent["product_id"]]
    n_uncomparable = (dependent_full["정가수량"] < MIN_FULL_PRICE_QTY).sum()
    print(f"\n할인 의존 상품 중 정가 판매 표본({MIN_FULL_PRICE_QTY}개 미만)이 부족해 "
          f"'대조 불가'로 분류되는 상품: {n_uncomparable}개")
    print(
        "\n논점 정리: 할인 판매 비중이 정의상 80% 이상인 상품군은 정가 판매 표본이 태생적으로 "
        "작아, '정가로도 잘 팔릴 것이다'라는 주장도 '정가로는 안 팔린다'는 주장도 이 데이터만 "
        "으로는 통계적으로 확증하기 어렵습니다. 실제 가격 정책 결정 전에는 일정 기간 정가 노출 "
        "테스트가 필요합니다."
    )
    return dependent


def problem_16():
    print("\n########## 문제 16: 할인 마진 잠식 시뮬레이션 ##########")
    net = _net_with_margin()

    actual_sales = net["line_amount"].sum()
    actual_margin = net["margin"].sum()

    # 할인이 없었다면(동일 수량 가정): 정가 매출 = 수량 x unit_price(할인전 단가)
    no_discount_sales = (net["quantity"] * net["unit_price"]).sum()
    no_discount_margin = (net["quantity"] * (net["unit_price"] - net["cost"])).sum()
    foregone = no_discount_sales - actual_sales

    print(f"\n실제 순매출: {actual_sales:,.0f} / 실제 마진: {actual_margin:,.0f}")
    print(f"할인 없었다면(동일 수량 가정) 매출: {no_discount_sales:,.0f} / 마진: {no_discount_margin:,.0f}")
    print(f"할인으로 포기한 금액(동일 수량 가정, 낙관적 상한): {foregone:,.0f}")

    # 시나리오: 할인이 없었다면 수량이 20%/50% 줄었을 것이라는 가정
    discounted = net[net["discount"] > 0].copy()
    non_discounted = net[net["discount"] == 0].copy()

    scenarios = {}
    for drop_rate, name in [(0.0, "동일수량(0%감소)"), (0.2, "20%감소"), (0.5, "50%감소")]:
        qty_factor = 1 - drop_rate
        sim_qty = discounted["quantity"] * qty_factor
        sim_sales = (sim_qty * discounted["unit_price"]).sum() + non_discounted["line_amount"].sum()
        sim_margin = (sim_qty * (discounted["unit_price"] - discounted["cost"])).sum() + \
                     non_discounted["margin"].sum()
        scenarios[name] = {"매출": sim_sales, "마진": sim_margin}

    scenario_df = pd.DataFrame(scenarios).T
    scenario_df.loc["실제(할인 적용)"] = {"매출": actual_sales, "마진": actual_margin}
    print("\n[실제 대 시나리오별 손익 대조표]")
    print(scenario_df.round(0).to_string())

    # 손익분기 감소율 역산: 할인 판매가 정가 판매보다 마진이 커지는 수량 유지율 x 를 구함
    # 정가라면: qty * (unit_price - cost)
    # 할인 후:  qty * x * (sale_price - cost)   (x=수량 유지율)
    # 손익분기: x = (unit_price-cost) / (sale_price-cost)  (단, sale_price-cost>0인 라인만)
    valid = discounted[discounted["sale_price"] > discounted["cost"]]
    breakeven_x = ((valid["unit_price"] - valid["cost"]) / (valid["sale_price"] - valid["cost"])).clip(upper=1)
    avg_breakeven_retention = np.average(breakeven_x, weights=valid["quantity"])
    print(f"\n손익분기 감소율(수량 가중 평균): 할인 판매 수량의 최소 "
          f"{avg_breakeven_retention:.1%}가 '할인 덕분에 발생한 수량'이어야 할인이 마진 관점에서 "
          f"정당화됩니다. (환산: 할인이 없었다면 수량이 이보다 더 크게 줄었을 경우 할인은 손해)")
    return scenario_df


if __name__ == "__main__":
    problem_14()
    problem_15()
    problem_16()
