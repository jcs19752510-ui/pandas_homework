# -*- coding: utf-8 -*-
"""
generate_shop_data.py
======================
※ 이 파일은 문제집에 "동봉되어 있다"고 언급된 원본 generate_shop_data.py 파일이 아닙니다
  (원본은 이번 대화에 첨부되지 않았습니다). 첨부해 주신 스크린샷 속 컬럼 구성·행 수·결측
  패턴을 최대한 동일하게 재현한 대체 생성기이며, seed=42로 고정해 몇 번을 실행해도 같은
  데이터가 나옵니다. 원본 파일을 가지고 계시다면 그것을 우선 사용하시고, 이 파일은 30개
  풀이 코드가 실제로 돌아가는지 확인·연습하는 용도로 쓰시면 됩니다.

실행:
    python generate_shop_data.py
  -> data/ 폴더에 customers.csv, products.csv, orders.csv, order_items.csv, web_logs.csv 생성
"""
import numpy as np
import pandas as pd
import os

rng = np.random.default_rng(42)
OUT_DIR = "data"
os.makedirs(OUT_DIR, exist_ok=True)

CATEGORIES = ["전자", "가구", "식품", "뷰티", "도서", "패션"]
CITIES = ["서울", "부산", "인천", "대구", "대전", "광주"]
CHANNELS = ["web", "app", "store"]


def gen_customers(n=5000):
    ids = np.arange(1, n + 1)
    names = [f"고객{i}" for i in ids]
    gender = rng.choice(["남", "여", None], size=n, p=[0.45, 0.49, 0.06])
    birth = pd.to_datetime("1960-01-01") + pd.to_timedelta(
        rng.integers(0, 365 * 45, size=n), unit="D"
    )
    birth = birth.where(rng.random(n) > 0.077, pd.NaT)  # 약 384명 결측
    signup = pd.to_datetime("2020-01-01") + pd.to_timedelta(
        rng.integers(0, 365 * 4, size=n), unit="D"
    )
    city = rng.choice(CITIES, size=n)
    email = [f"user{i}@example.com" for i in ids]
    email = pd.Series(email).where(rng.random(n) > 0.05, None)

    df = pd.DataFrame({
        "customer_id": ids, "name": names, "gender": gender,
        "birth_date": birth.strftime("%Y-%m-%d"), "signup_date": signup.strftime("%Y-%m-%d"),
        "city": city, "email": email,
    })
    df.loc[df["birth_date"] == "NaT", "birth_date"] = np.nan
    # 완전 중복 50행 추가
    dup = df.sample(50, random_state=42)
    df = pd.concat([df, dup], ignore_index=True)
    return df


def gen_products(n=500):
    ids = np.arange(1, n + 1)
    cat = rng.choice(CATEGORIES, size=n)
    # 카테고리 일부에 앞뒤 공백 오염
    cat = np.array([f" {c}" if rng.random() < 0.1 else c for c in cat])
    names = [f"{c.strip()} 상품{i}" for i, c in zip(ids, cat)]
    price = rng.integers(1000, 100000, size=n).astype(object)
    cost = (price.astype(float) * rng.uniform(0.3, 0.8, size=n)).round(0)

    # price 오염: 콤마/원 문자, 0, 음수, 결측
    price_str = []
    for i, p in enumerate(price):
        r = rng.random()
        if r < 0.02:
            price_str.append(f"{p:,}")
        elif r < 0.04:
            price_str.append(f"{p}원")
        elif r < 0.05:
            price_str.append("0")
        elif r < 0.06:
            price_str.append(str(-abs(int(p))))
        elif r < 0.07:
            price_str.append(None)
        else:
            price_str.append(str(p))

    df = pd.DataFrame({
        "product_id": ids, "product_name": names, "category": cat,
        "price": price_str, "cost": cost,
    })
    dup = df.sample(3, random_state=42)
    df = pd.concat([df, dup], ignore_index=True)
    return df


def gen_orders(n=200_000, n_customers=5000):
    ids = np.arange(1, n + 1)
    cust = rng.integers(1, n_customers + 200, size=n)  # 고객마스터보다 넓은 범위(정합성 문제 재현)
    start = pd.Timestamp("2024-01-01")
    dt = start + pd.to_timedelta(rng.integers(0, 181 * 24 * 3600, size=n), unit="s")
    dt_str = dt.strftime("%Y-%m-%d %H:%M:%S")
    dt_str = pd.Series(dt_str)
    dt_str.iloc[:1933] = ""  # 빈 문자열 오염
    dt_str.iloc[1933:1973] = "2025-01-15 10:00:00"  # 기간 밖 40건
    dt_str = dt_str.sample(frac=1, random_state=42).reset_index(drop=True)

    channel = rng.choice(CHANNELS, size=n, p=[0.5, 0.3, 0.2])
    status = rng.choice(
        ["delivered", "canceled", "returned", "shipped", "processing"],
        size=n, p=[0.55, 0.10, 0.05, 0.20, 0.10],
    )

    df = pd.DataFrame({
        "order_id": ids, "customer_id": cust, "order_datetime": dt_str,
        "channel": channel, "status": status,
    })
    return df


def gen_order_items(n=500_000, n_orders=200_000, n_products=500):
    ids = np.arange(1, n + 1)
    order_id = rng.integers(1, n_orders + 1, size=n)
    product_id = rng.integers(1, n_products + 1, size=n)
    quantity = rng.integers(1, 6, size=n)
    unit_price = rng.choice([9900, 15000, 20300, 68600, 90000, 10500, 3900, 93200], size=n).astype(float)
    unit_price_series = pd.Series(unit_price)
    unit_price_series.iloc[:15113] = np.nan
    unit_price_series = unit_price_series.sample(frac=1, random_state=42).reset_index(drop=True)
    discount = rng.choice([0, 0.05, 0.1, 0.15, 0.2, 0.23, 0.3, 0.45], size=n,
                           p=[0.15, 0.2, 0.2, 0.15, 0.1, 0.08, 0.07, 0.05])

    df = pd.DataFrame({
        "order_item_id": ids, "order_id": order_id, "product_id": product_id,
        "quantity": quantity, "unit_price": unit_price_series, "discount": discount,
    })
    dup = df.sample(120, random_state=42)
    df = pd.concat([df, dup], ignore_index=True)
    return df


def gen_web_logs(n=1_000_000, n_customers=5000, n_products=500):
    ids = np.arange(1, n + 1)
    customer_id = rng.integers(1, n_customers + 1, size=n).astype(float)
    cust_series = pd.Series(customer_id)
    cust_series.iloc[:350041] = np.nan
    cust_series = cust_series.sample(frac=1, random_state=42).reset_index(drop=True)

    start = pd.Timestamp("2024-01-01")
    dt = start + pd.to_timedelta(rng.integers(0, 181 * 24 * 3600, size=n), unit="s")

    event_type = rng.choice(["view", "search", "cart", "purchase"], size=n, p=[0.55, 0.15, 0.15, 0.15])
    product_id = rng.integers(1, n_products + 1, size=n).astype(float)
    prod_series = pd.Series(product_id)
    prod_series[event_type == "search"] = np.nan
    session_id = [f"sess_{rng.integers(0, 999999999):09x}" for _ in range(n)]

    df = pd.DataFrame({
        "log_id": ids, "customer_id": cust_series, "event_time": dt.strftime("%Y-%m-%d %H:%M:%S"),
        "event_type": event_type, "product_id": prod_series, "session_id": session_id,
    })
    return df


if __name__ == "__main__":
    print("데이터 생성 중 (seed=42, 재현 가능)...")
    customers = gen_customers()
    products = gen_products()
    orders = gen_orders()
    order_items = gen_order_items()
    web_logs = gen_web_logs()

    customers.to_csv(f"{OUT_DIR}/customers.csv", index=False)
    products.to_csv(f"{OUT_DIR}/products.csv", index=False)
    orders.to_csv(f"{OUT_DIR}/orders.csv", index=False)
    order_items.to_csv(f"{OUT_DIR}/order_items.csv", index=False)
    web_logs.to_csv(f"{OUT_DIR}/web_logs.csv", index=False)

    print(f"완료: customers {len(customers):,} / products {len(products):,} / "
          f"orders {len(orders):,} / order_items {len(order_items):,} / web_logs {len(web_logs):,}")
    print(f"'{OUT_DIR}/' 폴더에 CSV 5개가 생성되었습니다.")
