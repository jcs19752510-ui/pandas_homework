# -*- coding: utf-8 -*-
"""
10장. 대용량 로그 마케팅 파이프라인
  문제 27: 100만 행 로그 메모리 진단과 최적화
  문제 28: 청크 집계로 일별 활성 고객 산출
  문제 29: 로그 기반 상품 관심 스코어 파이프라인
  문제 30: 월간 마케팅 지표 자동화 파이프라인
"""
import pandas as pd
import numpy as np
import time
from common import DATA_DIR, load_products, build_net_sales_ledger, load_orders, load_order_items

WEB_LOGS_PATH = f"{DATA_DIR}/web_logs.csv"


def problem_27():
    print("\n########## 문제 27: 100만 행 로그 메모리 진단과 최적화 ##########")

    # 1) 아무 옵션 없이 적재
    raw = pd.read_csv(WEB_LOGS_PATH)
    mem_before = raw.memory_usage(deep=True)
    print("\n[옵션 없이 적재 시 메모리 사용량(열별, MB)]")
    print((mem_before / 1e6).round(2).to_string())
    print(f"총합: {mem_before.sum() / 1e6:.1f} MB")

    # 2) 단계적 최적화
    optimized = raw.copy()
    # 숫자열 다운캐스트
    optimized["log_id"] = pd.to_numeric(optimized["log_id"], downcast="integer")
    optimized["customer_id"] = pd.to_numeric(optimized["customer_id"], downcast="float")
    optimized["product_id"] = pd.to_numeric(optimized["product_id"], downcast="float")
    mem_after_downcast = optimized.memory_usage(deep=True).sum()

    # 저카디널리티 문자열 category 변환
    n_event_type = raw["event_type"].nunique()
    n_session = raw["session_id"].nunique()
    print(f"\nevent_type 고유값 수: {n_event_type} (전체 {len(raw):,}행 대비 매우 낮음 -> category 유리)")
    print(f"session_id 고유값 수: {n_session:,} (행 수와 비슷 -> category 오히려 불리)")
    optimized["event_type"] = optimized["event_type"].astype("category")
    mem_after_category = optimized.memory_usage(deep=True).sum()

    print(f"\n[단계별 메모리]")
    print(f"원본: {mem_before.sum() / 1e6:.1f} MB")
    print(f"다운캐스트 후: {mem_after_downcast / 1e6:.1f} MB "
          f"(절감 {(1 - mem_after_downcast / mem_before.sum()):.1%})")
    print(f"event_type category 변환 후: {mem_after_category / 1e6:.1f} MB "
          f"(절감 {(1 - mem_after_category / mem_before.sum()):.1%})")

    # usecols 선택 적재 (필요한 열만)
    usecols = ["customer_id", "event_time", "event_type", "product_id", "session_id"]
    slim = pd.read_csv(
        WEB_LOGS_PATH, usecols=usecols,
        dtype={"customer_id": "float32", "product_id": "float32", "event_type": "category"},
    )
    mem_slim = slim.memory_usage(deep=True).sum()
    print(f"usecols+dtype 지정 적재: {mem_slim / 1e6:.1f} MB "
          f"(원본 대비 절감 {(1 - mem_slim / mem_before.sum()):.1%})")

    def standard_loader():
        """팀 배포용 표준 적재 함수"""
        dtype_map = {
            "log_id": "int32", "customer_id": "float32", "product_id": "float32",
            "event_type": "category",
        }
        return pd.read_csv(WEB_LOGS_PATH, dtype=dtype_map, parse_dates=["event_time"])

    print("\nbefore/after 절감 요약: "
          f"{mem_before.sum() / 1e6:.1f} MB -> {mem_slim / 1e6:.1f} MB "
          f"({(1 - mem_slim / mem_before.sum()):.1%} 절감)")
    print("결론: session_id처럼 거의 행마다 값이 다른(고카디널리티) 열은 category 변환이 오히려 "
          "손해이므로, event_type처럼 고유값이 적은 열에만 선택적으로 적용해야 합니다.")
    return standard_loader


def problem_28():
    print("\n########## 문제 28: 청크 집계로 일별 활성 고객 산출 ##########")

    def chunked_dau(chunksize):
        daily_customers = {}
        event_counts = {}
        for chunk in pd.read_csv(
            WEB_LOGS_PATH, usecols=["customer_id", "event_time", "event_type"], chunksize=chunksize
        ):
            chunk = chunk.dropna(subset=["customer_id"])  # 익명 방문 제외
            chunk["date"] = pd.to_datetime(chunk["event_time"]).dt.date
            for date, group in chunk.groupby("date"):
                daily_customers.setdefault(date, set()).update(group["customer_id"].unique())
            for (date, etype), cnt in chunk.groupby(["date", "event_type"]).size().items():
                event_counts[(date, etype)] = event_counts.get((date, etype), 0) + cnt
        dau = pd.Series({d: len(s) for d, s in daily_customers.items()}).sort_index()
        events = pd.Series(event_counts).unstack(fill_value=0)
        return dau, events

    t0 = time.perf_counter()
    dau, events = chunked_dau(chunksize=100_000)
    t1 = time.perf_counter()
    print(f"\n청크 처리 소요시간(청크크기 100,000): {t1 - t0:.2f}초")
    print("\n[일별 DAU] (앞 10일)")
    print(dau.head(10).to_string())
    print("\n[일별 이벤트유형별 건수] (앞 5일)")
    print(events.head(5).to_string())

    # 전량 적재 결과와 대조
    full = pd.read_csv(WEB_LOGS_PATH, usecols=["customer_id", "event_time"]).dropna(subset=["customer_id"])
    full["date"] = pd.to_datetime(full["event_time"]).dt.date
    dau_full = full.groupby("date")["customer_id"].nunique().sort_index()
    match = (dau.reindex(dau_full.index) == dau_full).all()
    print(f"\n청크 결과와 전량 적재 결과 DAU 일치 여부: {match}")

    # 청크 크기별 시간 비교
    for cs in [50_000, 200_000]:
        t0 = time.perf_counter()
        chunked_dau(chunksize=cs)
        t1 = time.perf_counter()
        print(f"청크크기 {cs:,}: {t1 - t0:.2f}초")
    print("\n권장 청크 크기: 파일 크기와 가용 메모리에 따라 다르지만, 처리 시간과 오버헤드의 "
          "균형점인 100,000~200,000행 단위를 권장합니다. 너무 작으면 청크 반복 오버헤드가, "
          "너무 크면 메모리 절감 효과가 줄어듭니다.")
    return dau, events


def problem_29():
    print("\n########## 문제 29: 로그 기반 상품 관심 스코어 파이프라인 ##########")
    products = load_products()  # category 공백 정제 포함(common.py)

    WEIGHTS = {"view": 1, "cart": 3, "purchase": 5}
    RECENCY_BOOST = {6: 1.5}  # 6월 이벤트 1.5배

    def compute_interest_score(chunksize=200_000, top_n=20):
        acc = {}  # (product_id, event_type, is_recent) -> count
        for chunk in pd.read_csv(
            WEB_LOGS_PATH, usecols=["product_id", "event_type", "event_time"], chunksize=chunksize
        ):
            chunk = chunk.dropna(subset=["product_id"])  # search 이벤트 등 product_id 결측 제외
            chunk["event_time"] = pd.to_datetime(chunk["event_time"])
            chunk["month"] = chunk["event_time"].dt.month
            grouped = chunk.groupby(["product_id", "event_type", "month"]).size()
            for (pid, etype, month), cnt in grouped.items():
                key = (pid, etype, month)
                acc[key] = acc.get(key, 0) + cnt

        records = pd.DataFrame(
            [{"product_id": k[0], "event_type": k[1], "month": k[2], "count": v} for k, v in acc.items()]
        )
        records["weight"] = records["event_type"].map(WEIGHTS)
        records["recency_mult"] = records["month"].map(RECENCY_BOOST).fillna(1.0)
        records["weighted"] = records["count"] * records["weight"] * records["recency_mult"]

        score = records.groupby("product_id")["weighted"].sum().rename("관심스코어")
        report = score.sort_values(ascending=False).head(top_n).reset_index()
        report = report.merge(products[["product_id", "product_name", "category", "price"]], on="product_id", how="left")
        return report

    print(f"\n[가중치 가정] view={WEIGHTS['view']}, cart={WEIGHTS['cart']}, purchase={WEIGHTS['purchase']}, "
          f"6월 이벤트 {RECENCY_BOOST[6]}배 가중")
    top20 = compute_interest_score()
    print("\n[상위 20 상품 관심 스코어 리포트]")
    print(top20.to_string(index=False))

    # 민감도: 가중치를 바꿨을 때 순위 흔들림 확인 (purchase 가중치 5->8)
    def compute_with_custom_weight(purchase_weight):
        old = WEIGHTS["purchase"]
        WEIGHTS["purchase"] = purchase_weight
        r = compute_interest_score(top_n=20)
        WEIGHTS["purchase"] = old
        return r["product_id"].tolist()

    base_rank = top20["product_id"].tolist()
    alt_rank = compute_with_custom_weight(8)
    overlap = len(set(base_rank) & set(alt_rank))
    print(f"\n민감도 점검(purchase 가중치 5->8): 상위 20 중 {overlap}개 상품이 그대로 유지됨")
    return top20


def problem_30():
    print("\n########## 문제 30: 월간 마케팅 지표 자동화 파이프라인 ##########")

    def load_and_clean():
        """적재(dtype·기간) -> 정제(중복·타입·상태 규칙)"""
        result = build_net_sales_ledger(verbose=False)
        return result["net_ledger"], result["gross_ledger"]

    def metric_net_sales(net_ledger, month):
        m = net_ledger[net_ledger["order_datetime"].dt.to_period("M") == pd.Period(month, "M")]
        value = m["line_amount"].sum()
        assert value >= 0, "월 순매출은 음수일 수 없습니다"
        return value

    def metric_channel_aov(net_ledger, month):
        m = net_ledger[net_ledger["order_datetime"].dt.to_period("M") == pd.Period(month, "M")]
        order_amt = m.groupby(["order_id", "channel"])["line_amount"].sum().reset_index()
        aov = order_amt.groupby("channel")["line_amount"].mean()
        assert (aov > 0).all(), "채널별 AOV는 양수여야 합니다"
        return aov

    def metric_new_sales_share(net_ledger, month):
        first_month = net_ledger.groupby("customer_id")["order_datetime"].min().dt.to_period("M")
        m = net_ledger[net_ledger["order_datetime"].dt.to_period("M") == pd.Period(month, "M")].copy()
        m["is_new"] = m["customer_id"].map(first_month) == pd.Period(month, "M")
        share = m.loc[m["is_new"], "line_amount"].sum() / m["line_amount"].sum()
        assert 0 <= share <= 1, "신규 매출 비중은 0~1 사이여야 합니다"
        return share

    def metric_m1_retention(net_ledger, month):
        """M+1 리텐션 = 전월(m-1) 첫 구매 코호트가 당월(m)에 재구매한 비율"""
        target = pd.Period(month, "M")
        prev = target - 1
        first_month = net_ledger.groupby("customer_id")["order_datetime"].min().dt.to_period("M")
        cohort_customers = first_month[first_month == prev].index
        if len(cohort_customers) == 0:
            return np.nan
        cur_buyers = set(
            net_ledger.loc[net_ledger["order_datetime"].dt.to_period("M") == target, "customer_id"]
        )
        retained = sum(1 for c in cohort_customers if c in cur_buyers)
        rate = retained / len(cohort_customers)
        assert 0 <= rate <= 1
        return rate

    def metric_funnel_conversion(month):
        """해당 월 web_logs 세션 view->purchase 전환율"""
        logs = pd.read_csv(WEB_LOGS_PATH, usecols=["event_type", "event_time", "session_id"])
        logs["event_time"] = pd.to_datetime(logs["event_time"])
        m = logs[logs["event_time"].dt.to_period("M") == pd.Period(month, "M")]
        reach = m.drop_duplicates(subset=["session_id", "event_type"])
        matrix = pd.crosstab(reach["session_id"], reach["event_type"]) > 0
        n_view = matrix.get("view", pd.Series(dtype=bool)).sum()
        n_purchase = matrix.get("purchase", pd.Series(dtype=bool)).sum()
        rate = n_purchase / n_view if n_view else np.nan
        assert rate is np.nan or 0 <= rate <= 1
        return rate

    def run_monthly_report(month: str, save=True):
        """month 예: '2024-06'. 적재->정제->지표5종->CSV저장을 한번에 수행."""
        net_ledger, gross_ledger = load_and_clean()

        report = {
            "월": month,
            "월순매출": metric_net_sales(net_ledger, month),
            "M+1리텐션": metric_m1_retention(net_ledger, month),
            "신규매출비중": metric_new_sales_share(net_ledger, month),
            "퍼널전환율": metric_funnel_conversion(month),
        }
        channel_aov = metric_channel_aov(net_ledger, month)
        for ch, v in channel_aov.items():
            report[f"AOV_{ch}"] = v

        report_df = pd.DataFrame([report])
        if save:
            out_path = f"monthly_report_{month}.csv"
            report_df.to_csv(out_path, index=False, encoding="utf-8-sig")
            print(f"저장됨: {out_path}")
        return report_df

    print("\n[운영 수칙] 각 지표 함수는 assert로 자가 검증하며, 검증 실패 시 즉시 예외를 발생시켜 "
          "잘못된 수치가 리포트에 실리는 것을 막습니다. run_monthly_report(month)만 호출하면 "
          "적재부터 저장까지 전 과정이 재실행됩니다.")

    report_may = run_monthly_report("2024-05")
    print("\n[5월 리포트]")
    print(report_may.round(4).to_string(index=False))

    report_jun = run_monthly_report("2024-06")
    print("\n[6월 리포트]")
    print(report_jun.round(4).to_string(index=False))

    # 재실행으로 동일하게 재현되는지 확인
    report_jun_2 = run_monthly_report("2024-06", save=False)
    reproducible = report_jun.drop(columns="월").equals(report_jun_2.drop(columns="월"))
    print(f"\n재실행 재현성 확인(6월 재실행 결과 동일 여부): {reproducible}")
    print(
        "\nM+1 리텐션을 '당월 코호트가 다음달에 재구매'로 정의하면 마지막 달(6월) 리포트를 만들 때 "
        "아직 오지 않은 7월 데이터가 필요해 계산이 불가능해집니다. 그래서 '전월 코호트가 당월에 "
        "재구매'로 방향을 뒤집어, 항상 당월까지의 데이터만으로 계산되도록 설계했습니다."
    )
    return run_monthly_report


if __name__ == "__main__":
    problem_27()
    problem_28()
    problem_29()
    problem_30()
